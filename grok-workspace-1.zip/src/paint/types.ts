export type Tool =
  | "brush"
  | "pencil"
  | "eraser"
  | "fill"
  | "eyedropper"
  | "shape"
  | "select"
  | "hand";

export type BrushKind =
  | "hard"
  | "soft"
  | "spray"
  | "calligraphy"
  | "watercolor"
  | "charcoal"
  | "crayon"
  | "pencil";

export type ShapeKind = "line" | "rect" | "ellipse";

export type ToolSettings = {
  size: number;
  opacity: number;
  hardness: number;
};

export type LayerSnapshot = {
  id: string;
  name: string;
  visible: boolean;
  opacity: number;
  active: boolean;
};

export type ReferenceSnapshot = {
  opacity: number;
  locked: boolean;
  rotation: number;
  scale: number;
};

export type Snapshot = {
  ready: boolean;
  restoring: boolean;
  tool: Tool;
  color: string;
  recent: string[];
  size: number;
  opacity: number;
  hardness: number;
  brushKind: BrushKind;
  eraserSoft: boolean;
  shape: ShapeKind;
  filled: boolean;
  symmetric: boolean;
  fillTolerance: number;
  canUndo: boolean;
  canRedo: boolean;
  zoom: number;
  paper: string;
  layers: LayerSnapshot[];
  reference: ReferenceSnapshot | null;
  hasInk: boolean;
  savedTick: number;
  message: string | null;
};

export const ART_PRESETS = [
  { id: "portrait", label: "پرتره", w: 1080, h: 1440 },
  { id: "landscape", label: "منظره", w: 1440, h: 1080 },
  { id: "square", label: "مربع", w: 1080, h: 1080 },
  { id: "large", label: "بزرگ", w: 1440, h: 1920 },
] as const;

export const PIGMENTS = [
  "#1c1917",
  "#f4efe6",
  "#e24b3a",
  "#e07a3d",
  "#f0c14a",
  "#7d9a4e",
  "#2f7d6d",
  "#2a6f97",
  "#3d4e8f",
  "#8a4f86",
  "#c46b7a",
  "#6b4634",
] as const;

export const PAPERS = ["#f4efe6", "#fffdf8", "#efe6d6", "#d7c4a3", "#2a2e33", "#1c1917"] as const;

export const BRUSH_KINDS: { id: BrushKind; label: string }[] = [
  { id: "hard", label: "سخت" },
  { id: "soft", label: "نرم" },
  { id: "spray", label: "اسپری" },
  { id: "calligraphy", label: "خوشنویسی" },
  { id: "watercolor", label: "آبرنگ" },
  { id: "charcoal", label: "زغال" },
  { id: "crayon", label: "شمعی" },
];

export function defaultSettings(): Record<Tool, ToolSettings> {
  return {
    brush: { size: 22, opacity: 1, hardness: 0.78 },
    pencil: { size: 4, opacity: 1, hardness: 0.92 },
    eraser: { size: 28, opacity: 1, hardness: 0.7 },
    fill: { size: 24, opacity: 1, hardness: 1 },
    eyedropper: { size: 12, opacity: 1, hardness: 1 },
    shape: { size: 6, opacity: 1, hardness: 1 },
    select: { size: 12, opacity: 1, hardness: 1 },
    hand: { size: 12, opacity: 1, hardness: 1 },
  };
}

export function defaultSnapshot(): Snapshot {
  const settings = defaultSettings();
  return {
    ready: false,
    restoring: true,
    tool: "brush",
    color: "#1c1917",
    recent: PIGMENTS.slice(0, 8).map((c) => c),
    size: settings.brush.size,
    opacity: settings.brush.opacity,
    hardness: settings.brush.hardness,
    brushKind: "soft",
    eraserSoft: false,
    shape: "rect",
    filled: false,
    symmetric: false,
    fillTolerance: 22,
    canUndo: false,
    canRedo: false,
    zoom: 1,
    paper: "#f4efe6",
    layers: [],
    reference: null,
    hasInk: false,
    savedTick: 0,
    message: null,
  };
}
