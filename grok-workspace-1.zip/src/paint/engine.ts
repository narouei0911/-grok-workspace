import { drawStamp, spacingFor } from "@/paint/brushes";
import { hexToRgb, rgbToHex } from "@/paint/color";
import { floodFill, type Rect } from "@/paint/flood";
import { clamp, clampRect, constrainEnd, drawShape, shapeBounds, unionRect } from "@/paint/geom";
import { History } from "@/paint/history";
import {
  blobToImage,
  canvasToBlob,
  loadDoc,
  loadPrefs,
  mergeSettings,
  saveDoc,
  savePrefs,
  type Prefs,
  type SavedDoc,
} from "@/paint/storage";
import {
  PIGMENTS,
  defaultSettings,
  type BrushKind,
  type ShapeKind,
  type Snapshot,
  type Tool,
  type ToolSettings,
} from "@/paint/types";

type Mode =
  | "idle"
  | "draw"
  | "pan"
  | "panzoom"
  | "refmove"
  | "refpinch"
  | "shape"
  | "select"
  | "fill"
  | "pick";

type PointerPos = { sx: number; sy: number; cx: number; cy: number };

type Layer = {
  id: string;
  name: string;
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  visible: boolean;
  opacity: number;
};

type Reference = {
  source: CanvasImageSource;
  x: number;
  y: number;
  w: number;
  h: number;
  baseW: number;
  baseH: number;
  rotation: number;
  opacity: number;
  locked: boolean;
};

type Sel = { x: number; y: number; w: number; h: number; dx: number; dy: number };

const MIN_ZOOM = 0.5;
const MAX_ZOOM = 8;
const MAX_LAYERS = 6;

function uid(): string {
  return `l${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

function ctx2d(canvas: HTMLCanvasElement): CanvasRenderingContext2D {
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("canvas");
  return ctx;
}

export class PaintEngine {
  artW = 1080;
  artH = 1440;

  private studio!: HTMLElement;
  private stage!: HTMLElement;
  private world!: HTMLElement;
  private topbar: HTMLElement | null = null;
  private dock: HTMLElement | null = null;

  private paper!: HTMLCanvasElement;
  private refCanvas!: HTMLCanvasElement;
  private mask!: HTMLCanvasElement;
  private preview!: HTMLCanvasElement;
  private overlay!: HTMLCanvasElement;
  private chrome!: HTMLCanvasElement;
  private snapshot!: HTMLCanvasElement;

  private paperCtx!: CanvasRenderingContext2D;
  private refCtx!: CanvasRenderingContext2D;
  private maskCtx!: CanvasRenderingContext2D;
  private previewCtx!: CanvasRenderingContext2D;
  private overlayCtx!: CanvasRenderingContext2D;
  private chromeCtx!: CanvasRenderingContext2D;

  private layers: Layer[] = [];
  private active = 0;
  private paperColor = "#f4efe6";
  private ref: Reference | null = null;
  private refBlob: Blob | null = null;

  private tool: Tool = "brush";
  private color = "#1c1917";
  private recent: string[] = PIGMENTS.slice(0, 8).map((c) => c);
  private brushKind: BrushKind = "soft";
  private eraserSoft = false;
  private shape: ShapeKind = "rect";
  private filled = false;
  private symmetric = false;
  private fillTolerance = 22;
  private settings: Record<Tool, ToolSettings> = defaultSettings();

  private history = new History();
  private hasInk = false;
  private panX = 0;
  private panY = 0;
  private scale = 1;
  private userMovedView = false;
  private lastAspect = 1;

  private pointers = new Map<number, PointerPos>();
  private mode: Mode = "idle";
  private activePointer = -1;
  private refGesture = false;
  private pointerIsPen = false;
  private drawing = false;
  private points: { x: number; y: number; p: number }[] = [];
  private sx = 0;
  private sy = 0;
  private hasStamp = false;
  private spaceDown = false;
  private toolBeforeSpace: Tool | null = null;

  private pinch: { dist: number; scale: number; ax: number; ay: number } | null = null;
  private panStart = { x: 0, y: 0, sx: 0, sy: 0 };
  private refStart = { x: 0, y: 0, px: 0, py: 0 };
  private refPinch: {
    dist: number;
    ang: number;
    w: number;
    h: number;
    rot: number;
    cx: number;
    cy: number;
    midX: number;
    midY: number;
  } | null = null;

  private shapeA: PointerPos | null = null;
  private shapeB: PointerPos | null = null;
  private sel: Sel | null = null;
  private draft: Rect | null = null;
  private selectMode: "none" | "marquee" | "move" = "none";
  private lift: HTMLCanvasElement | null = null;
  private moveOrigin: PointerPos | null = null;

  private sprayRaf = 0;
  private liveRaf = 0;
  private saveTimer = 0;
  private msgTimer = 0;
  private resizeObs: ResizeObserver | null = null;
  private message: string | null = null;
  private savedTick = 0;
  private restoring = true;
  private ready = false;
  private destroyed = false;
  private restoreGen = 0;
  private listeners = new Set<() => void>();

  onZoom: ((scale: number) => void) | null = null;

  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit(): void {
    for (const fn of this.listeners) fn();
  }

  getSnapshot(): Snapshot {
    const st = this.settings[this.tool];
    return {
      ready: this.ready,
      restoring: this.restoring,
      tool: this.tool,
      color: this.color,
      recent: this.recent,
      size: st.size,
      opacity: st.opacity,
      hardness: st.hardness,
      brushKind: this.brushKind,
      eraserSoft: this.eraserSoft,
      shape: this.shape,
      filled: this.filled,
      symmetric: this.symmetric,
      fillTolerance: this.fillTolerance,
      canUndo: this.history.canUndo,
      canRedo: this.history.canRedo,
      zoom: this.scale,
      paper: this.paperColor,
      layers: this.layers.map((layer, i) => ({
        id: layer.id,
        name: layer.name,
        visible: layer.visible,
        opacity: layer.opacity,
        active: i === this.active,
      })),
      reference: this.ref
        ? {
            opacity: this.ref.opacity,
            locked: this.ref.locked,
            rotation: this.ref.rotation,
            scale: this.ref.baseW > 0 ? this.ref.w / this.ref.baseW : 1,
          }
        : null,
      hasInk: this.hasInk,
      savedTick: this.savedTick,
      message: this.message,
    };
  }

  attach(studio: HTMLElement, stage: HTMLElement, world: HTMLElement): void {
    this.studio = studio;
    this.stage = stage;
    this.world = world;
    this.topbar = studio.querySelector(".topbar");
    this.dock = studio.querySelector(".dock");
    this.applyPrefs(loadPrefs());
    this.paper = this.makeCanvas("paper");
    this.refCanvas = this.makeCanvas("ref");
    this.mask = this.makeCanvas("mask");
    this.preview = this.makeCanvas("preview");
    this.overlay = this.makeCanvas("overlay");
    this.chrome = this.makeCanvas("chrome");
    this.snapshot = document.createElement("canvas");
    this.bindContexts();
    this.resizeBacking(this.snapshot);
    world.append(this.paper, this.refCanvas, this.mask, this.preview, this.overlay, this.chrome);
    this.mask.style.visibility = "hidden";
    this.preview.style.visibility = "hidden";
    this.addLayerInternal("لایه ۱");
    this.drawPaper();
    this.orderDom();
    this.bind();
    this.fit(false);
    this.ready = true;
    void this.restore();
    this.emit();
  }

  destroy(): void {
    this.destroyed = true;
    this.restoreGen++;
    cancelAnimationFrame(this.sprayRaf);
    cancelAnimationFrame(this.liveRaf);
    window.clearTimeout(this.saveTimer);
    window.clearTimeout(this.msgTimer);
    this.resizeObs?.disconnect();
    this.stage?.removeEventListener("pointerdown", this.onDown);
    this.stage?.removeEventListener("pointermove", this.onMove);
    this.stage?.removeEventListener("pointerup", this.onUp);
    this.stage?.removeEventListener("pointercancel", this.onUp);
    this.stage?.removeEventListener("wheel", this.onWheel);
    this.stage?.removeEventListener("contextmenu", this.onContext);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    document.removeEventListener("visibilitychange", this.onVis);
    this.listeners.clear();
  }

  private applyPrefs(prefs: Partial<Prefs> | null): void {
    if (!prefs) return;
    const tools: Tool[] = ["brush", "pencil", "eraser", "fill", "eyedropper", "shape", "select", "hand"];
    const kinds: BrushKind[] = ["hard", "soft", "spray", "calligraphy", "watercolor", "charcoal", "crayon", "pencil"];
    const shapes: ShapeKind[] = ["line", "rect", "ellipse"];
    if (typeof prefs.color === "string") this.color = prefs.color;
    if (prefs.recent?.length) this.recent = prefs.recent.filter((c) => typeof c === "string").slice(0, 12);
    if (prefs.tool && tools.includes(prefs.tool)) this.tool = prefs.tool;
    if (prefs.brushKind && kinds.includes(prefs.brushKind)) this.brushKind = prefs.brushKind;
    if (typeof prefs.eraserSoft === "boolean") this.eraserSoft = prefs.eraserSoft;
    if (prefs.shape && shapes.includes(prefs.shape)) this.shape = prefs.shape;
    if (typeof prefs.filled === "boolean") this.filled = prefs.filled;
    if (typeof prefs.symmetric === "boolean") this.symmetric = prefs.symmetric;
    if (typeof prefs.fillTolerance === "number") this.fillTolerance = prefs.fillTolerance;
    if (typeof prefs.paper === "string") this.paperColor = prefs.paper;
    this.settings = mergeSettings(prefs);
  }

  private makeCanvas(name: string): HTMLCanvasElement {
    const canvas = document.createElement("canvas");
    canvas.className = `c-layer c-${name}`;
    canvas.width = this.artW;
    canvas.height = this.artH;
    return canvas;
  }

  private bindContexts(): void {
    this.paperCtx = ctx2d(this.paper);
    this.refCtx = ctx2d(this.refCanvas);
    this.maskCtx = ctx2d(this.mask);
    this.previewCtx = ctx2d(this.preview);
    this.overlayCtx = ctx2d(this.overlay);
    this.chromeCtx = ctx2d(this.chrome);
  }

  private resizeBacking(canvas: HTMLCanvasElement): void {
    canvas.width = this.artW;
    canvas.height = this.artH;
  }

  private bind(): void {
    this.stage.addEventListener("pointerdown", this.onDown, { passive: false });
    this.stage.addEventListener("pointermove", this.onMove, { passive: false });
    this.stage.addEventListener("pointerup", this.onUp);
    this.stage.addEventListener("pointercancel", this.onUp);
    this.stage.addEventListener("wheel", this.onWheel, { passive: false });
    this.stage.addEventListener("contextmenu", this.onContext);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    document.addEventListener("visibilitychange", this.onVis);
    this.resizeObs = new ResizeObserver(() => this.onResize());
    this.resizeObs.observe(this.stage);
    this.syncCursor();
  }

  private onResize = (): void => {
    const rect = this.stage.getBoundingClientRect();
    const aspect = rect.width / Math.max(1, rect.height);
    if (!this.userMovedView || Math.abs(aspect - this.lastAspect) > 0.35) this.fit(false);
    this.lastAspect = aspect;
    this.drawChrome();
  };

  private insets(): { top: number; bottom: number } {
    return {
      top: this.topbar?.getBoundingClientRect().height ?? 56,
      bottom: this.dock?.getBoundingClientRect().height ?? 76,
    };
  }

  fit(_markUser = false): void {
    const rect = this.stage.getBoundingClientRect();
    if (rect.width < 8 || rect.height < 8) return;
    const { top, bottom } = this.insets();
    const availW = Math.max(40, rect.width - 28);
    const availH = Math.max(40, rect.height - top - bottom - 20);
    const next = clamp(Math.min(availW / this.artW, availH / this.artH), MIN_ZOOM, MAX_ZOOM);
    this.scale = next;
    this.panX = (rect.width - this.artW * next) / 2;
    this.panY = top + (rect.height - top - bottom - this.artH * next) / 2;
    this.userMovedView = false;
    this.applyView();
    this.onZoom?.(this.scale);
    this.emit();
  }

  zoomBy(factor: number): void {
    const rect = this.stage.getBoundingClientRect();
    const { top, bottom } = this.insets();
    this.zoomAt(rect.width / 2, top + (rect.height - top - bottom) / 2, this.scale * factor);
    this.userMovedView = true;
    this.onZoom?.(this.scale);
    this.emit();
  }

  private zoomAt(sx: number, sy: number, nextScale: number): void {
    const next = clamp(nextScale, MIN_ZOOM, MAX_ZOOM);
    const cx = (sx - this.panX) / this.scale;
    const cy = (sy - this.panY) / this.scale;
    this.scale = next;
    this.panX = sx - cx * next;
    this.panY = sy - cy * next;
    this.applyView();
    this.drawChrome();
  }

  private applyView(): void {
    this.world.style.width = `${this.artW}px`;
    this.world.style.height = `${this.artH}px`;
    this.world.style.transform = `translate(${this.panX}px, ${this.panY}px) scale(${this.scale})`;
  }

  private locate(e: { clientX: number; clientY: number }): PointerPos {
    const stage = this.stage.getBoundingClientRect();
    const world = this.world.getBoundingClientRect();
    const sx = e.clientX - stage.left;
    const sy = e.clientY - stage.top;
    const width = world.width || 1;
    const height = world.height || 1;
    return {
      sx,
      sy,
      cx: ((e.clientX - world.left) / width) * this.artW,
      cy: ((e.clientY - world.top) / height) * this.artH,
    };
  }

  private onContext = (e: Event): void => {
    e.preventDefault();
  };

  private onWheel = (e: WheelEvent): void => {
    e.preventDefault();
    const pos = this.locate(e);
    const factor = e.deltaY < 0 ? 1.08 : 1 / 1.08;
    this.userMovedView = true;
    this.zoomAt(pos.sx, pos.sy, this.scale * factor);
    this.onZoom?.(this.scale);
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    const target = e.target as HTMLElement | null;
    const typing = !!target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA");
    const meta = e.metaKey || e.ctrlKey;
    if (meta && e.key.toLowerCase() === "z") {
      e.preventDefault();
      if (e.shiftKey) this.redo();
      else this.undo();
      return;
    }
    if (meta && (e.key.toLowerCase() === "y" || (e.shiftKey && e.key.toLowerCase() === "z"))) {
      e.preventDefault();
      this.redo();
      return;
    }
    if (typing) return;
    if (e.key === "[") this.setSize(this.settings[this.tool].size - 2);
    if (e.key === "]") this.setSize(this.settings[this.tool].size + 2);
    if (e.key === " " && !this.spaceDown) {
      e.preventDefault();
      this.spaceDown = true;
      this.toolBeforeSpace = this.tool;
      this.setTool("hand");
      return;
    }
    if (meta || e.altKey) return;
    const map: Record<string, Tool> = {
      b: "brush",
      n: "pencil",
      e: "eraser",
      g: "fill",
      i: "eyedropper",
      s: "shape",
      v: "select",
      h: "hand",
    };
    const next = map[e.key.toLowerCase()];
    if (next) this.setTool(next);
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    if (e.key === " " && this.spaceDown) {
      this.spaceDown = false;
      if (this.toolBeforeSpace) this.setTool(this.toolBeforeSpace);
      this.toolBeforeSpace = null;
    }
  };

  private onVis = (): void => {
    if (document.visibilityState === "hidden") void this.persist();
  };

  private onDown = (e: PointerEvent): void => {
    if (this.restoring || e.button !== 0) return;
    e.preventDefault();
    this.stage.setPointerCapture(e.pointerId);
    const pos = this.locate(e);
    this.pointers.set(e.pointerId, pos);

    if (this.pointers.size >= 2) {
      const editingRef = this.refGesture && !!this.ref && !this.ref.locked;
      if (!editingRef) this.abortLive();
      if (editingRef) {
        this.mode = "refpinch";
        this.beginRefPinch();
      } else {
        this.mode = "panzoom";
        this.refGesture = false;
        this.beginPinch();
      }
      return;
    }

    this.activePointer = e.pointerId;
    this.pointerIsPen = e.pointerType === "pen";
    const hand = this.tool === "hand" || e.altKey || this.spaceDown;

    if (this.ref && !this.ref.locked && !hand && this.tool !== "eyedropper" && this.hitRef(pos.cx, pos.cy)) {
      this.mode = "refmove";
      this.refGesture = true;
      this.refStart = { x: this.ref.x, y: this.ref.y, px: pos.cx, py: pos.cy };
      return;
    }
    this.refGesture = false;

    if (hand) {
      this.mode = "pan";
      this.panStart = { x: this.panX, y: this.panY, sx: pos.sx, sy: pos.sy };
      this.userMovedView = true;
      return;
    }
    if (this.tool === "eyedropper") {
      this.mode = "pick";
      this.pickAt(pos.cx, pos.cy);
      return;
    }
    if (this.tool === "fill") {
      this.mode = "fill";
      this.doFill(pos.cx, pos.cy);
      return;
    }
    if (this.tool === "shape") {
      this.mode = "shape";
      this.shapeA = pos;
      this.shapeB = pos;
      return;
    }
    if (this.tool === "select") {
      this.mode = "select";
      this.beginSelect(pos);
      return;
    }
    this.mode = "draw";
    this.beginStroke(pos.cx, pos.cy, e.pressure);
  };

  private onMove = (e: PointerEvent): void => {
    if (!this.pointers.has(e.pointerId)) return;
    const pos = this.locate(e);
    this.pointers.set(e.pointerId, pos);
    if (this.mode === "panzoom" && this.pointers.size >= 2) {
      this.updatePinch();
      return;
    }
    if (this.mode === "refpinch" && this.pointers.size >= 2) {
      this.updateRefPinch();
      return;
    }
    if (e.pointerId !== this.activePointer) return;
    if (this.mode === "refmove" && this.ref) {
      this.ref.x = this.refStart.x + (pos.cx - this.refStart.px);
      this.ref.y = this.refStart.y + (pos.cy - this.refStart.py);
      this.drawRef();
      return;
    }
    if (this.mode === "pan") {
      this.panX = this.panStart.x + (pos.sx - this.panStart.sx);
      this.panY = this.panStart.y + (pos.sy - this.panStart.sy);
      this.applyView();
      return;
    }
    if (this.mode === "draw" && this.drawing) {
      const events = e.getCoalescedEvents?.() ?? [e];
      for (const ev of events) {
        const p = this.locate(ev);
        this.points.push({ x: p.cx, y: p.cy, p: ev.pressure });
        this.advance(p.cx, p.cy, ev.pressure || 0);
      }
      this.schedulePreview();
      return;
    }
    if (this.mode === "shape") {
      this.shapeB = pos;
      this.paintShapeOverlay();
      return;
    }
    if (this.mode === "select") {
      this.updateSelect(pos);
      return;
    }
    if (this.mode === "pick") this.pickAt(pos.cx, pos.cy);
  };

  private onUp = (e: PointerEvent): void => {
    this.pointers.delete(e.pointerId);
    if (this.mode === "panzoom" || this.mode === "refpinch") {
      if (this.pointers.size < 2) {
        if (this.mode === "refpinch") this.scheduleSave();
        this.mode = "idle";
        this.refGesture = false;
        this.pinch = null;
        this.refPinch = null;
        this.emit();
      }
      return;
    }
    if (this.pointers.size > 0) return;
    if (this.mode === "draw") this.commitStroke();
    else if (this.mode === "shape") this.commitShape();
    else if (this.mode === "select") this.endSelect();
    else if (this.mode === "refmove") {
      this.scheduleSave();
      this.emit();
    } else if (this.mode === "pick") {
      this.rememberColor();
      this.emit();
    }
    this.mode = "idle";
    this.refGesture = false;
    this.shapeA = null;
  };

  private beginPinch(): void {
    const pts = [...this.pointers.values()];
    if (pts.length < 2) return;
    const dist = Math.hypot(pts[0]!.sx - pts[1]!.sx, pts[0]!.sy - pts[1]!.sy) || 1;
    const midX = (pts[0]!.sx + pts[1]!.sx) / 2;
    const midY = (pts[0]!.sy + pts[1]!.sy) / 2;
    this.pinch = {
      dist,
      scale: this.scale,
      ax: (midX - this.panX) / this.scale,
      ay: (midY - this.panY) / this.scale,
    };
    this.userMovedView = true;
  }

  private updatePinch(): void {
    const pts = [...this.pointers.values()];
    if (pts.length < 2 || !this.pinch) return;
    const dist = Math.hypot(pts[0]!.sx - pts[1]!.sx, pts[0]!.sy - pts[1]!.sy) || 1;
    const midX = (pts[0]!.sx + pts[1]!.sx) / 2;
    const midY = (pts[0]!.sy + pts[1]!.sy) / 2;
    const next = clamp(this.pinch.scale * (dist / this.pinch.dist), MIN_ZOOM, MAX_ZOOM);
    this.scale = next;
    this.panX = midX - this.pinch.ax * next;
    this.panY = midY - this.pinch.ay * next;
    this.applyView();
    this.drawChrome();
    this.onZoom?.(this.scale);
  }

  private beginRefPinch(): void {
    if (!this.ref) return;
    const pts = [...this.pointers.values()];
    if (pts.length < 2) return;
    this.refPinch = {
      dist: Math.hypot(pts[0]!.cx - pts[1]!.cx, pts[0]!.cy - pts[1]!.cy) || 1,
      ang: Math.atan2(pts[1]!.cy - pts[0]!.cy, pts[1]!.cx - pts[0]!.cx),
      w: this.ref.w,
      h: this.ref.h,
      rot: this.ref.rotation,
      cx: this.ref.x + this.ref.w / 2,
      cy: this.ref.y + this.ref.h / 2,
      midX: (pts[0]!.cx + pts[1]!.cx) / 2,
      midY: (pts[0]!.cy + pts[1]!.cy) / 2,
    };
  }

  private updateRefPinch(): void {
    if (!this.ref || !this.refPinch) return;
    const pts = [...this.pointers.values()];
    if (pts.length < 2) return;
    const dist = Math.hypot(pts[0]!.cx - pts[1]!.cx, pts[0]!.cy - pts[1]!.cy) || 1;
    const ang = Math.atan2(pts[1]!.cy - pts[0]!.cy, pts[1]!.cx - pts[0]!.cx);
    const midX = (pts[0]!.cx + pts[1]!.cx) / 2;
    const midY = (pts[0]!.cy + pts[1]!.cy) / 2;
    const s = clamp(dist / this.refPinch.dist, 0.15, 6);
    this.ref.w = Math.max(36, this.refPinch.w * s);
    this.ref.h = Math.max(36, this.refPinch.h * s);
    this.ref.rotation = this.refPinch.rot + (ang - this.refPinch.ang);
    const cx = this.refPinch.cx + (midX - this.refPinch.midX);
    const cy = this.refPinch.cy + (midY - this.refPinch.midY);
    this.ref.x = cx - this.ref.w / 2;
    this.ref.y = cy - this.ref.h / 2;
    this.drawRef();
  }

  private hitRef(x: number, y: number): boolean {
    if (!this.ref) return false;
    const cx = this.ref.x + this.ref.w / 2;
    const cy = this.ref.y + this.ref.h / 2;
    const dx = x - cx;
    const dy = y - cy;
    const cos = Math.cos(-this.ref.rotation);
    const sin = Math.sin(-this.ref.rotation);
    const lx = dx * cos - dy * sin;
    const ly = dx * sin + dy * cos;
    return Math.abs(lx) <= this.ref.w / 2 && Math.abs(ly) <= this.ref.h / 2;
  }

  private abortLive(): void {
    if (this.mode === "draw") this.cancelStroke();
    if (this.mode === "shape") {
      this.clearCanvas(this.overlay);
      this.overlay.style.visibility = "hidden";
    }
    if (this.mode === "select" && this.selectMode === "move") {
      this.preview.style.visibility = "hidden";
      this.showActiveLayer();
      if (this.sel) {
        this.sel.dx = 0;
        this.sel.dy = 0;
      }
    }
    this.draft = null;
    this.selectMode = "none";
    this.drawing = false;
    cancelAnimationFrame(this.sprayRaf);
    this.sprayRaf = 0;
    this.drawChrome();
  }

  private activeLayer(): Layer {
    return this.layers[this.active] ?? this.layers[0]!;
  }

  private drawKind(): BrushKind {
    if (this.tool === "pencil") return "pencil";
    if (this.tool === "eraser") return this.eraserSoft ? "soft" : "hard";
    if (this.tool === "brush") return this.brushKind;
    return "hard";
  }

  private isEraser(): boolean {
    return this.tool === "eraser";
  }

  private radius(pressure: number): number {
    const base = Math.max(0.5, this.settings[this.tool].size / 2);
    if (this.pointerIsPen) {
      const p = pressure > 0 ? pressure : 0.5;
      return Math.max(0.4, base * (0.2 + 0.8 * p));
    }
    return base;
  }

  private beginStroke(x: number, y: number, pressure: number): void {
    const layer = this.activeLayer();
    if (!layer.visible) {
      layer.visible = true;
      this.syncLayerStyles();
    }
    this.drawing = true;
    this.points = [{ x, y, p: pressure }];
    this.hasStamp = false;
    if (this.isEraser()) this.copyLayerTo(this.snapshot, layer);
    this.clearCanvas(this.mask);
    if (this.isEraser()) {
      this.mask.style.visibility = "hidden";
      this.preview.style.visibility = "visible";
      this.preview.style.opacity = String(layer.opacity);
      layer.canvas.style.visibility = "hidden";
    } else {
      this.preview.style.visibility = "hidden";
      this.mask.style.visibility = "visible";
      this.mask.style.opacity = String(this.settings[this.tool].opacity * layer.opacity);
    }
    this.advance(x, y, pressure);
    if (this.drawKind() === "spray") this.loopSpray();
    if (this.isEraser()) this.renderEraserPreview();
  }

  private advance(x: number, y: number, pressure: number): void {
    const radius = this.radius(pressure);
    if (!this.hasStamp) {
      this.emitStamp(x, y, radius, 0);
      this.sx = x;
      this.sy = y;
      this.hasStamp = true;
      return;
    }
    const dx = x - this.sx;
    const dy = y - this.sy;
    const dist = Math.hypot(dx, dy);
    const step = spacingFor(this.drawKind(), radius, this.settings[this.tool].hardness);
    if (dist < step) return;
    const angle = Math.atan2(dy, dx);
    const steps = Math.floor(dist / step);
    for (let i = 1; i <= steps; i++) {
      const t = (i * step) / dist;
      this.emitStamp(this.sx + dx * t, this.sy + dy * t, radius, angle);
    }
    const used = steps * step;
    this.sx += (dx / dist) * used;
    this.sy += (dy / dist) * used;
  }

  private emitStamp(x: number, y: number, radius: number, angle: number): void {
    drawStamp(
      this.maskCtx,
      this.drawKind(),
      x,
      y,
      radius,
      this.isEraser() ? "#000000" : this.color,
      this.settings[this.tool].hardness,
      angle,
    );
  }

  private loopSpray(): void {
    if (this.sprayRaf) return;
    const tick = () => {
      if (!this.drawing || this.drawKind() !== "spray") {
        this.sprayRaf = 0;
        return;
      }
      const last = this.points[this.points.length - 1];
      if (last) this.emitStamp(last.x, last.y, this.radius(last.p), 0);
      this.sprayRaf = requestAnimationFrame(tick);
    };
    this.sprayRaf = requestAnimationFrame(tick);
  }

  private schedulePreview(): void {
    if (!this.isEraser() || this.liveRaf) return;
    this.liveRaf = requestAnimationFrame(() => {
      this.liveRaf = 0;
      if (this.drawing && this.isEraser()) this.renderEraserPreview();
    });
  }

  private renderEraserPreview(): void {
    const ctx = this.previewCtx;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.clearRect(0, 0, this.artW, this.artH);
    ctx.drawImage(this.snapshot, 0, 0);
    ctx.globalAlpha = this.settings.eraser.opacity;
    ctx.globalCompositeOperation = "destination-out";
    ctx.drawImage(this.mask, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  private strokeBounds(): Rect | null {
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const p of this.points) {
      if (p.x < minX) minX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.x > maxX) maxX = p.x;
      if (p.y > maxY) maxY = p.y;
    }
    if (!Number.isFinite(minX)) return null;
    const pad = this.settings[this.tool].size * 1.8 + 24;
    return clampRect(minX - pad, minY - pad, maxX - minX + pad * 2, maxY - minY + pad * 2, this.artW, this.artH);
  }

  private commitStroke(): void {
    if (!this.drawing) return;
    this.drawing = false;
    cancelAnimationFrame(this.sprayRaf);
    this.sprayRaf = 0;
    const layer = this.activeLayer();
    const rect = this.strokeBounds();
    try {
      if (!rect) return;
      const before = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
      layer.ctx.save();
      layer.ctx.globalAlpha = this.settings[this.tool].opacity;
      layer.ctx.globalCompositeOperation = this.isEraser() ? "destination-out" : "source-over";
      layer.ctx.drawImage(this.mask, 0, 0);
      layer.ctx.restore();
      const after = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
      this.history.push(layer.id, rect, before, after);
      this.hasInk = true;
      if (!this.isEraser()) this.rememberColor();
      this.scheduleSave();
    } finally {
      this.showActiveLayer();
      this.clearCanvas(this.mask);
      this.emit();
    }
  }

  private cancelStroke(): void {
    this.drawing = false;
    cancelAnimationFrame(this.sprayRaf);
    this.sprayRaf = 0;
    this.showActiveLayer();
    this.clearCanvas(this.mask);
  }

  private showActiveLayer(): void {
    const layer = this.activeLayer();
    this.preview.style.visibility = "hidden";
    this.mask.style.visibility = "hidden";
    layer.canvas.style.visibility = layer.visible ? "visible" : "hidden";
  }

  private paintShapeOverlay(): void {
    if (!this.shapeA || !this.shapeB) return;
    const end = constrainEnd(
      this.shape,
      this.shapeA.cx,
      this.shapeA.cy,
      this.shapeB.cx,
      this.shapeB.cy,
      this.symmetric,
    );
    this.clearCanvas(this.overlay);
    drawShape(
      this.overlayCtx,
      this.shape,
      this.shapeA.cx,
      this.shapeA.cy,
      end.x1,
      end.y1,
      this.filled,
      this.settings.shape.size,
      this.color,
    );
    const layer = this.activeLayer();
    this.overlay.style.visibility = "visible";
    this.overlay.style.opacity = String(this.settings.shape.opacity * layer.opacity);
  }

  private commitShape(): void {
    if (!this.shapeA || !this.shapeB) return;
    const end = constrainEnd(
      this.shape,
      this.shapeA.cx,
      this.shapeA.cy,
      this.shapeB.cx,
      this.shapeB.cy,
      this.symmetric,
    );
    const rect = shapeBounds(
      this.shapeA.cx,
      this.shapeA.cy,
      end.x1,
      end.y1,
      this.filled ? 2 : this.settings.shape.size,
      this.artW,
      this.artH,
    );
    this.clearCanvas(this.overlay);
    this.overlay.style.visibility = "hidden";
    if (!rect) return;
    if (Math.hypot(end.x1 - this.shapeA.cx, end.y1 - this.shapeA.cy) < 1) return;
    const layer = this.activeLayer();
    const before = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
    this.clearCanvas(this.mask);
    drawShape(
      this.maskCtx,
      this.shape,
      this.shapeA.cx,
      this.shapeA.cy,
      end.x1,
      end.y1,
      this.filled,
      this.settings.shape.size,
      this.color,
    );
    layer.ctx.save();
    layer.ctx.globalAlpha = this.settings.shape.opacity;
    layer.ctx.drawImage(this.mask, 0, 0);
    layer.ctx.restore();
    this.clearCanvas(this.mask);
    const after = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
    this.history.push(layer.id, rect, before, after);
    this.hasInk = true;
    this.rememberColor();
    this.scheduleSave();
    this.emit();
  }

  private doFill(x: number, y: number): void {
    const ix = x | 0;
    const iy = y | 0;
    if (ix < 0 || iy < 0 || ix >= this.artW || iy >= this.artH) return;
    const layer = this.activeLayer();
    if (!layer.visible) {
      layer.visible = true;
      this.syncLayerStyles();
    }
    const img = layer.ctx.getImageData(0, 0, this.artW, this.artH);
    const { r, g, b } = hexToRgb(this.color);
    const alpha = Math.round(this.settings.fill.opacity * 255);
    const beforeFull = new ImageData(new Uint8ClampedArray(img.data), this.artW, this.artH);
    const box = floodFill(img.data, this.artW, this.artH, ix, iy, [r, g, b, alpha], this.fillTolerance);
    if (!box) return;
    const before = sliceImage(beforeFull, box);
    layer.ctx.putImageData(img, 0, 0);
    const after = layer.ctx.getImageData(box.x, box.y, box.w, box.h);
    this.history.push(layer.id, box, before, after);
    this.hasInk = true;
    this.rememberColor();
    this.scheduleSave();
    this.emit();
  }

  private pickAt(x: number, y: number): void {
    const ix = x | 0;
    const iy = y | 0;
    if (ix < 0 || iy < 0 || ix >= this.artW || iy >= this.artH) return;
    let dst = { ...hexToRgb(this.paperColor), a: 1 };
    const over = (src: { r: number; g: number; b: number; a: number }) => {
      const ia = 1 - src.a;
      dst = {
        r: src.r * src.a + dst.r * ia,
        g: src.g * src.a + dst.g * ia,
        b: src.b * src.a + dst.b * ia,
        a: src.a + dst.a * ia,
      };
    };
    const sample = (canvas: HTMLCanvasElement) => {
      const data = ctx2d(canvas).getImageData(ix, iy, 1, 1).data;
      return { r: data[0]!, g: data[1]!, b: data[2]!, a: data[3]! / 255 };
    };
    const refPx = sample(this.refCanvas);
    if (refPx.a > 0.004) over(refPx);
    for (const layer of this.layers) {
      if (!layer.visible) continue;
      const px = sample(layer.canvas);
      const a = px.a * layer.opacity;
      if (a < 0.004) continue;
      over({ r: px.r, g: px.g, b: px.b, a });
    }
    this.color = rgbToHex(dst.r, dst.g, dst.b);
    this.emit();
  }

  private beginSelect(pos: PointerPos): void {
    if (this.sel && pointIn(pos.cx, pos.cy, this.sel.x + this.sel.dx, this.sel.y + this.sel.dy, this.sel.w, this.sel.h)) {
      this.selectMode = "move";
      this.prepareMove(pos);
      return;
    }
    this.sel = null;
    this.selectMode = "marquee";
    this.moveOrigin = pos;
    this.draft = { x: pos.cx, y: pos.cy, w: 0, h: 0 };
    this.drawChrome();
  }

  private prepareMove(pos: PointerPos): void {
    if (!this.sel) return;
    const layer = this.activeLayer();
    this.copyLayerTo(this.snapshot, layer);
    const c = document.createElement("canvas");
    const w = Math.max(1, Math.ceil(this.sel.w));
    const h = Math.max(1, Math.ceil(this.sel.h));
    c.width = w;
    c.height = h;
    ctx2d(c).drawImage(layer.canvas, this.sel.x, this.sel.y, this.sel.w, this.sel.h, 0, 0, w, h);
    this.lift = c;
    this.sel.dx = 0;
    this.sel.dy = 0;
    this.moveOrigin = pos;
    this.preview.style.visibility = "visible";
    this.preview.style.opacity = String(layer.opacity);
    layer.canvas.style.visibility = "hidden";
    this.renderSelectionPreview();
  }

  private updateSelect(pos: PointerPos): void {
    if (this.selectMode === "marquee" && this.moveOrigin) {
      const x = Math.min(this.moveOrigin.cx, pos.cx);
      const y = Math.min(this.moveOrigin.cy, pos.cy);
      this.draft = {
        x,
        y,
        w: Math.abs(pos.cx - this.moveOrigin.cx),
        h: Math.abs(pos.cy - this.moveOrigin.cy),
      };
      this.drawChrome();
      return;
    }
    if (this.selectMode === "move" && this.sel && this.moveOrigin) {
      this.sel.dx = pos.cx - this.moveOrigin.cx;
      this.sel.dy = pos.cy - this.moveOrigin.cy;
      this.renderSelectionPreview();
      this.drawChrome();
    }
  }

  private renderSelectionPreview(): void {
    if (!this.sel || !this.lift) return;
    const ctx = this.previewCtx;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.clearRect(0, 0, this.artW, this.artH);
    ctx.drawImage(this.snapshot, 0, 0);
    ctx.clearRect(this.sel.x, this.sel.y, this.sel.w, this.sel.h);
    ctx.drawImage(this.lift, this.sel.x + this.sel.dx, this.sel.y + this.sel.dy);
  }

  private endSelect(): void {
    if (this.selectMode === "marquee" && this.draft && this.draft.w > 4 && this.draft.h > 4) {
      const rect = clampRect(this.draft.x, this.draft.y, this.draft.w, this.draft.h, this.artW, this.artH);
      this.sel = rect ? { ...rect, dx: 0, dy: 0 } : null;
    }
    if (this.selectMode === "move" && this.sel && (this.sel.dx !== 0 || this.sel.dy !== 0)) {
      this.commitMove();
    } else if (this.selectMode === "move") {
      this.preview.style.visibility = "hidden";
      this.showActiveLayer();
    }
    this.draft = null;
    this.selectMode = "none";
    this.drawChrome();
    this.emit();
  }

  private commitMove(): void {
    if (!this.sel || !this.lift) return;
    const layer = this.activeLayer();
    const next = clampRect(
      this.sel.x + this.sel.dx,
      this.sel.y + this.sel.dy,
      this.sel.w,
      this.sel.h,
      this.artW,
      this.artH,
    );
    const prev = clampRect(this.sel.x, this.sel.y, this.sel.w, this.sel.h, this.artW, this.artH);
    const rect = prev && next ? unionRect(prev, next) : prev || next;
    if (!rect) return;
    const before = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
    layer.ctx.save();
    layer.ctx.beginPath();
    layer.ctx.rect(rect.x, rect.y, rect.w, rect.h);
    layer.ctx.clip();
    layer.ctx.clearRect(rect.x, rect.y, rect.w, rect.h);
    layer.ctx.drawImage(this.preview, 0, 0);
    layer.ctx.restore();
    const after = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
    this.history.push(layer.id, rect, before, after);
    this.sel.x += this.sel.dx;
    this.sel.y += this.sel.dy;
    this.sel.dx = 0;
    this.sel.dy = 0;
    this.hasInk = true;
    this.preview.style.visibility = "hidden";
    this.showActiveLayer();
    this.scheduleSave();
  }

  private copyLayerTo(dest: HTMLCanvasElement, layer: Layer): void {
    if (dest.width !== this.artW || dest.height !== this.artH) this.resizeBacking(dest);
    const ctx = ctx2d(dest);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.clearRect(0, 0, this.artW, this.artH);
    ctx.drawImage(layer.canvas, 0, 0);
  }

  private clearCanvas(canvas: HTMLCanvasElement): void {
    const ctx = ctx2d(canvas);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  private orderDom(): void {
    const nodes: HTMLCanvasElement[] = [this.paper, this.refCanvas];
    this.layers.forEach((layer, i) => {
      nodes.push(layer.canvas);
      if (i === this.active) nodes.push(this.preview, this.mask, this.overlay);
    });
    nodes.push(this.chrome);
    for (const node of nodes) this.world.appendChild(node);
  }

  private syncLayerStyles(): void {
    for (const layer of this.layers) {
      layer.canvas.style.opacity = String(layer.opacity);
      if (layer.canvas.style.visibility !== "hidden" || layer !== this.activeLayer() || !this.drawing) {
        layer.canvas.style.visibility = layer.visible ? "visible" : "hidden";
      }
    }
  }

  private drawPaper(): void {
    this.paperCtx.setTransform(1, 0, 0, 1, 0, 0);
    this.paperCtx.globalAlpha = 1;
    this.paperCtx.fillStyle = this.paperColor;
    this.paperCtx.fillRect(0, 0, this.artW, this.artH);
  }

  private drawRef(): void {
    this.clearCanvas(this.refCanvas);
    if (this.ref) {
      this.refCtx.save();
      this.refCtx.globalAlpha = this.ref.opacity;
      this.refCtx.imageSmoothingEnabled = true;
      this.refCtx.imageSmoothingQuality = "high";
      this.refCtx.translate(this.ref.x + this.ref.w / 2, this.ref.y + this.ref.h / 2);
      this.refCtx.rotate(this.ref.rotation);
      this.refCtx.drawImage(this.ref.source, -this.ref.w / 2, -this.ref.h / 2, this.ref.w, this.ref.h);
      this.refCtx.restore();
    }
    this.drawChrome();
  }

  private drawChrome(): void {
    this.clearCanvas(this.chrome);
    const ctx = this.chromeCtx;
    const lw = 1.5 / this.scale;
    if (this.ref && !this.ref.locked) {
      ctx.save();
      ctx.translate(this.ref.x + this.ref.w / 2, this.ref.y + this.ref.h / 2);
      ctx.rotate(this.ref.rotation);
      ctx.strokeStyle = "rgba(224,122,61,0.95)";
      ctx.lineWidth = 2 / this.scale;
      ctx.setLineDash([8 / this.scale, 6 / this.scale]);
      ctx.strokeRect(-this.ref.w / 2, -this.ref.h / 2, this.ref.w, this.ref.h);
      ctx.restore();
    }
    const live = this.draft ?? (this.sel ? { x: this.sel.x + this.sel.dx, y: this.sel.y + this.sel.dy, w: this.sel.w, h: this.sel.h } : null);
    if (this.tool === "select" && live && live.w > 1 && live.h > 1) {
      ctx.save();
      ctx.strokeStyle = "#e07a3d";
      ctx.lineWidth = lw;
      ctx.setLineDash([6 / this.scale, 4 / this.scale]);
      ctx.strokeRect(live.x, live.y, live.w, live.h);
      ctx.restore();
    }
  }

  private createLayer(name: string, id = uid()): Layer {
    const canvas = this.makeCanvas("paint");
    const layer: Layer = {
      id,
      name,
      canvas,
      ctx: ctx2d(canvas),
      visible: true,
      opacity: 1,
    };
    canvas.style.opacity = "1";
    return layer;
  }

  private addLayerInternal(name: string): void {
    const layer = this.createLayer(name);
    this.layers.push(layer);
    this.active = this.layers.length - 1;
    this.orderDom();
  }

  private rebuildWorld(w: number, h: number): void {
    this.artW = w;
    this.artH = h;
    for (const canvas of [this.paper, this.refCanvas, this.mask, this.preview, this.overlay, this.chrome, this.snapshot]) {
      this.resizeBacking(canvas);
    }
    this.bindContexts();
    for (const layer of this.layers) layer.canvas.remove();
    this.layers = [];
    this.history.clear();
    this.sel = null;
    this.drawPaper();
  }

  setTool(tool: Tool): void {
    if (this.tool === "select" && tool !== "select") {
      this.sel = null;
      this.draft = null;
      this.drawChrome();
    }
    this.tool = tool;
    this.syncCursor();
    this.persistPrefs();
    this.emit();
  }

  setColor(color: string, remember = false): void {
    this.color = color;
    if (remember) this.rememberColor();
    this.emit();
  }

  setSize(size: number): void {
    this.settings[this.tool].size = clamp(Math.round(size), 1, 160);
    this.persistPrefs();
    this.emit();
  }

  setOpacity(opacity: number): void {
    this.settings[this.tool].opacity = clamp(opacity, 0.02, 1);
    this.persistPrefs();
    this.emit();
  }

  setHardness(hardness: number): void {
    this.settings[this.tool].hardness = clamp(hardness, 0, 1);
    this.persistPrefs();
    this.emit();
  }

  setBrushKind(kind: BrushKind): void {
    this.brushKind = kind;
    if (this.tool !== "brush") this.setTool("brush");
    else {
      this.persistPrefs();
      this.emit();
    }
  }

  setEraserSoft(soft: boolean): void {
    this.eraserSoft = soft;
    this.persistPrefs();
    this.emit();
  }

  setShape(shape: ShapeKind): void {
    this.shape = shape;
    if (this.tool !== "shape") this.tool = "shape";
    this.syncCursor();
    this.persistPrefs();
    this.emit();
  }

  setFilled(filled: boolean): void {
    this.filled = filled;
    this.persistPrefs();
    this.emit();
  }

  setSymmetric(symmetric: boolean): void {
    this.symmetric = symmetric;
    this.persistPrefs();
    this.emit();
  }

  setFillTolerance(tolerance: number): void {
    this.fillTolerance = clamp(Math.round(tolerance), 0, 90);
    this.persistPrefs();
    this.emit();
  }

  setPaper(color: string): void {
    this.paperColor = color;
    this.drawPaper();
    this.persistPrefs();
    this.scheduleSave();
    this.emit();
  }

  undo(): void {
    if (this.drawing) return;
    const patch = this.history.undo();
    if (!patch) return;
    const layer = this.layers.find((item) => item.id === patch.layerId);
    if (!layer) return;
    layer.ctx.putImageData(patch.before, patch.x, patch.y);
    this.scheduleSave();
    this.emit();
  }

  redo(): void {
    if (this.drawing) return;
    const patch = this.history.redo();
    if (!patch) return;
    const layer = this.layers.find((item) => item.id === patch.layerId);
    if (!layer) return;
    layer.ctx.putImageData(patch.after, patch.x, patch.y);
    this.hasInk = true;
    this.scheduleSave();
    this.emit();
  }

  clearLayer(): void {
    const layer = this.activeLayer();
    const before = layer.ctx.getImageData(0, 0, this.artW, this.artH);
    layer.ctx.clearRect(0, 0, this.artW, this.artH);
    const after = layer.ctx.getImageData(0, 0, this.artW, this.artH);
    this.history.push(layer.id, { x: 0, y: 0, w: this.artW, h: this.artH }, before, after);
    this.scheduleSave();
    this.flash("لایه پاک شد");
  }

  clearAll(): void {
    for (const layer of this.layers) {
      const before = layer.ctx.getImageData(0, 0, this.artW, this.artH);
      layer.ctx.clearRect(0, 0, this.artW, this.artH);
      const after = layer.ctx.getImageData(0, 0, this.artW, this.artH);
      this.history.push(layer.id, { x: 0, y: 0, w: this.artW, h: this.artH }, before, after);
    }
    this.scheduleSave();
    this.flash("بوم پاک شد");
  }

  addLayer(): void {
    if (this.layers.length >= MAX_LAYERS) {
      this.flash("حداکثر ۶ لایه");
      return;
    }
    const layer = this.createLayer(`لایه ${this.layers.length + 1}`);
    const index = this.active + 1;
    this.layers.splice(index, 0, layer);
    this.active = index;
    this.orderDom();
    this.syncLayerStyles();
    this.scheduleSave();
    this.emit();
  }

  deleteLayer(id: string): void {
    if (this.layers.length <= 1) {
      this.clearLayer();
      return;
    }
    const index = this.layers.findIndex((layer) => layer.id === id);
    if (index < 0) return;
    this.layers[index]!.canvas.remove();
    this.layers.splice(index, 1);
    this.active = Math.max(0, Math.min(this.active, this.layers.length - 1));
    this.orderDom();
    this.scheduleSave();
    this.emit();
  }

  moveLayer(id: string, dir: -1 | 1): void {
    const index = this.layers.findIndex((layer) => layer.id === id);
    const next = index + dir;
    if (index < 0 || next < 0 || next >= this.layers.length) return;
    const [layer] = this.layers.splice(index, 1);
    this.layers.splice(next, 0, layer!);
    if (this.active === index) this.active = next;
    else if (this.active === next) this.active = index;
    this.orderDom();
    this.scheduleSave();
    this.emit();
  }

  setActiveLayer(id: string): void {
    const index = this.layers.findIndex((layer) => layer.id === id);
    if (index < 0) return;
    this.active = index;
    this.sel = null;
    this.orderDom();
    this.drawChrome();
    this.scheduleSave();
    this.emit();
  }

  setLayerVisible(id: string, visible: boolean): void {
    const layer = this.layers.find((item) => item.id === id);
    if (!layer) return;
    layer.visible = visible;
    layer.canvas.style.visibility = visible ? "visible" : "hidden";
    this.scheduleSave();
    this.emit();
  }

  setLayerOpacity(id: string, opacity: number): void {
    const layer = this.layers.find((item) => item.id === id);
    if (!layer) return;
    layer.opacity = clamp(opacity, 0.05, 1);
    layer.canvas.style.opacity = String(layer.opacity);
    this.scheduleSave();
    this.emit();
  }

  async loadReference(file: File): Promise<void> {
    try {
      const img = await blobToImage(file);
      const maxEdge = Math.max(this.artW, this.artH) * 2;
      const scale = Math.min(1, maxEdge / Math.max(img.naturalWidth, img.naturalHeight));
      const src = document.createElement("canvas");
      src.width = Math.max(1, Math.round(img.naturalWidth * scale));
      src.height = Math.max(1, Math.round(img.naturalHeight * scale));
      ctx2d(src).drawImage(img, 0, 0, src.width, src.height);
      const blob = await canvasToBlob(src);
      const fit = Math.min((this.artW * 0.9) / src.width, (this.artH * 0.9) / src.height, 1);
      const w = Math.max(36, src.width * fit);
      const h = Math.max(36, src.height * fit);
      this.refBlob = blob;
      this.ref = {
        source: src,
        baseW: w,
        baseH: h,
        x: (this.artW - w) / 2,
        y: (this.artH - h) / 2,
        w,
        h,
        rotation: 0,
        opacity: 0.5,
        locked: false,
      };
      this.drawRef();
      this.scheduleSave();
      this.flash("عکس اضافه شد. بکشید، بعد قفل کنید");
    } catch {
      this.flash("خواندن عکس ممکن نشد");
    }
  }

  setRefOpacity(opacity: number): void {
    if (!this.ref) return;
    this.ref.opacity = clamp(opacity, 0.05, 1);
    this.drawRef();
    this.scheduleSave();
    this.emit();
  }

  setRefLocked(locked: boolean): void {
    if (!this.ref) return;
    this.ref.locked = locked;
    this.drawRef();
    this.scheduleSave();
    this.flash(locked ? "عکس قفل شد" : "عکس باز شد — می‌توانید جابه‌جا کنید");
  }

  setRefRotation(deg: number): void {
    if (!this.ref) return;
    this.ref.rotation = (deg * Math.PI) / 180;
    this.drawRef();
    this.scheduleSave();
    this.emit();
  }

  setRefScale(scale: number): void {
    if (!this.ref) return;
    const next = clamp(scale, 0.15, 4);
    const cx = this.ref.x + this.ref.w / 2;
    const cy = this.ref.y + this.ref.h / 2;
    this.ref.w = Math.max(36, this.ref.baseW * next);
    this.ref.h = Math.max(36, this.ref.baseH * next);
    this.ref.x = cx - this.ref.w / 2;
    this.ref.y = cy - this.ref.h / 2;
    this.drawRef();
    this.scheduleSave();
    this.emit();
  }

  clearReference(): void {
    this.ref = null;
    this.refBlob = null;
    this.drawRef();
    this.scheduleSave();
    this.flash("عکس مرجع حذف شد");
  }

  newDocument(w: number, h: number): void {
    this.ref = null;
    this.refBlob = null;
    this.hasInk = false;
    this.rebuildWorld(w, h);
    this.addLayerInternal("لایه ۱");
    this.syncLayerStyles();
    this.fit(false);
    this.scheduleSave();
    this.flash("بوم تازه آماده است");
  }

  async exportPng(withReference: boolean): Promise<void> {
    const canvas = document.createElement("canvas");
    canvas.width = this.artW;
    canvas.height = this.artH;
    const ctx = ctx2d(canvas);
    ctx.drawImage(this.paper, 0, 0);
    if (withReference) ctx.drawImage(this.refCanvas, 0, 0);
    for (const layer of this.layers) {
      if (!layer.visible) continue;
      ctx.globalAlpha = layer.opacity;
      ctx.drawImage(layer.canvas, 0, 0);
    }
    ctx.globalAlpha = 1;
    const blob = await canvasToBlob(canvas);
    const file = new File([blob], "negar.png", { type: "image/png" });
    const share = navigator.share?.bind(navigator);
    const can =
      typeof navigator.canShare === "function" &&
      (() => {
        try {
          return navigator.canShare({ files: [file] });
        } catch {
          return false;
        }
      })();
    if (share && can) {
      try {
        await share({ files: [file], title: "نگار" });
        return;
      } catch (error) {
        if (error instanceof Error && error.name === "AbortError") return;
      }
    }
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "negar.png";
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
    this.flash("فایل PNG ذخیره شد");
  }

  private rememberColor(): void {
    const color = this.color.toLowerCase();
    this.recent = [color, ...this.recent.filter((item) => item !== color)].slice(0, 12);
    this.persistPrefs();
  }

  private flash(message: string): void {
    this.message = message;
    this.emit();
    window.clearTimeout(this.msgTimer);
    this.msgTimer = window.setTimeout(() => {
      this.message = null;
      if (!this.destroyed) this.emit();
    }, 2400);
  }

  private persistPrefs(): void {
    const prefs: Prefs = {
      color: this.color,
      recent: this.recent,
      tool: this.tool,
      brushKind: this.brushKind,
      eraserSoft: this.eraserSoft,
      shape: this.shape,
      filled: this.filled,
      symmetric: this.symmetric,
      fillTolerance: this.fillTolerance,
      paper: this.paperColor,
      settings: this.settings,
    };
    savePrefs(prefs);
  }

  private scheduleSave(): void {
    window.clearTimeout(this.saveTimer);
    this.saveTimer = window.setTimeout(() => void this.persist(), 800);
  }

  private async persist(): Promise<void> {
    if (this.destroyed || this.restoring) return;
    try {
      const layers = [];
      for (const layer of this.layers) {
        layers.push({
          id: layer.id,
          name: layer.name,
          visible: layer.visible,
          opacity: layer.opacity,
          png: await canvasToBlob(layer.canvas),
        });
      }
      const doc: SavedDoc = {
        version: 1,
        artW: this.artW,
        artH: this.artH,
        paper: this.paperColor,
        hasInk: this.hasInk,
        activeId: this.activeLayer().id,
        layers,
        reference:
          this.ref && this.refBlob
            ? {
                png: this.refBlob,
                x: this.ref.x,
                y: this.ref.y,
                w: this.ref.w,
                h: this.ref.h,
                baseW: this.ref.baseW,
                baseH: this.ref.baseH,
                rotation: this.ref.rotation,
                opacity: this.ref.opacity,
                locked: this.ref.locked,
              }
            : null,
      };
      await saveDoc(doc);
      if (this.destroyed) return;
      this.savedTick++;
      this.emit();
    } catch {
      /* keep painting even if storage fails */
    }
  }

  private async restore(): Promise<void> {
    const gen = ++this.restoreGen;
    const doc = await loadDoc();
    if (this.destroyed || gen !== this.restoreGen) return;
    if (!doc || doc.version !== 1 || !doc.layers?.length) {
      this.restoring = false;
      this.fit(false);
      this.emit();
      return;
    }
    try {
      this.rebuildWorld(doc.artW, doc.artH);
      this.paperColor = doc.paper || this.paperColor;
      this.drawPaper();
      this.hasInk = !!doc.hasInk;
      for (const saved of doc.layers) {
        const layer = this.createLayer(saved.name, saved.id);
        layer.visible = saved.visible;
        layer.opacity = saved.opacity;
        const img = await blobToImage(saved.png);
        if (this.destroyed || gen !== this.restoreGen) return;
        layer.ctx.drawImage(img, 0, 0, this.artW, this.artH);
        layer.canvas.style.opacity = String(layer.opacity);
        layer.canvas.style.visibility = layer.visible ? "visible" : "hidden";
        this.layers.push(layer);
      }
      const index = this.layers.findIndex((layer) => layer.id === doc.activeId);
      this.active = index >= 0 ? index : this.layers.length - 1;
      if (doc.reference) {
        const img = await blobToImage(doc.reference.png);
        if (this.destroyed || gen !== this.restoreGen) return;
        const src = document.createElement("canvas");
        src.width = img.naturalWidth;
        src.height = img.naturalHeight;
        ctx2d(src).drawImage(img, 0, 0);
        this.refBlob = doc.reference.png;
        this.ref = {
          source: src,
          x: doc.reference.x,
          y: doc.reference.y,
          w: doc.reference.w,
          h: doc.reference.h,
          baseW: doc.reference.baseW,
          baseH: doc.reference.baseH,
          rotation: doc.reference.rotation,
          opacity: doc.reference.opacity,
          locked: doc.reference.locked,
        };
      }
      this.orderDom();
      this.drawRef();
      this.restoring = false;
      this.fit(false);
      if (doc.hasInk || doc.reference) this.flash("نقاشی بازیابی شد");
      else this.emit();
    } catch {
      if (this.layers.length === 0) {
        this.rebuildWorld(1080, 1440);
        this.addLayerInternal("لایه ۱");
        this.drawPaper();
      }
      this.restoring = false;
      this.fit(false);
      this.emit();
    }
  }

  private syncCursor(): void {
    const map: Record<Tool, string> = {
      brush: "crosshair",
      pencil: "crosshair",
      eraser: "cell",
      fill: "crosshair",
      eyedropper: "crosshair",
      shape: "crosshair",
      select: "crosshair",
      hand: "grab",
    };
    this.stage.style.cursor = map[this.tool];
  }
}

function pointIn(x: number, y: number, rx: number, ry: number, rw: number, rh: number): boolean {
  return x >= rx && y >= ry && x <= rx + rw && y <= ry + rh;
}

function sliceImage(full: ImageData, rect: Rect): ImageData {
  const out = new ImageData(rect.w, rect.h);
  for (let y = 0; y < rect.h; y++) {
    const src = ((rect.y + y) * full.width + rect.x) * 4;
    out.data.set(full.data.subarray(src, src + rect.w * 4), y * rect.w * 4);
  }
  return out;
}
