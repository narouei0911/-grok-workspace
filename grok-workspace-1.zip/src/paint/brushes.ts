import { hashUnit, hexToRgb, mixHex, shiftHue } from "@/paint/color";
import type { BrushKind } from "@/paint/types";

export function spacingFor(kind: BrushKind, radius: number, hardness: number): number {
  const r = Math.max(0.8, radius);
  switch (kind) {
    case "spray":
      return Math.max(2, r * 0.5);
    case "watercolor":
      return Math.max(2, r * 0.4);
    case "charcoal":
      return Math.max(1.2, r * 0.28);
    case "crayon":
      return Math.max(1.1, r * 0.2);
    case "calligraphy":
      return Math.max(0.7, r * 0.1);
    case "soft":
      return Math.max(0.7, r * (0.07 + 0.14 * (1 - hardness)));
    case "pencil":
      return Math.max(0.45, r * 0.22);
    default:
      return Math.max(0.5, r * 0.16);
  }
}

function stampSoft(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  hardness: number,
  alpha: number,
  color: string,
): void {
  const r = Math.max(0.8, radius);
  const inner = Math.max(0, Math.min(r - 0.35, r * hardness));
  const g = ctx.createRadialGradient(x, y, inner, x, y, r);
  const { r: cr, g: cg, b: cb } = hexToRgb(color);
  const a = Math.max(0, Math.min(1, alpha));
  g.addColorStop(0, `rgba(${cr | 0},${cg | 0},${cb | 0},${a})`);
  g.addColorStop(1, `rgba(${cr | 0},${cg | 0},${cb | 0},0)`);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

export function drawStamp(
  ctx: CanvasRenderingContext2D,
  kind: BrushKind,
  x: number,
  y: number,
  radius: number,
  color: string,
  hardness: number,
  angle: number,
): void {
  const r = Math.max(0.4, radius);
  ctx.save();
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";

  if (kind === "hard") {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  } else if (kind === "pencil") {
    const jitter = (1 - hardness) * r * 0.85;
    const jx = (hashUnit(x * 19.1 + y * 0.37) - 0.5) * jitter;
    const jy = (hashUnit(y * 13.7 + x * 0.17) - 0.5) * jitter;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x + jx, y + jy, Math.max(0.35, r * 0.82), 0, Math.PI * 2);
    ctx.fill();
    if (hashUnit(x * 3.1 + y * 5.7) > 0.62) {
      const { r: cr, g: cg, b: cb } = hexToRgb(color);
      ctx.fillStyle = `rgba(${cr},${cg},${cb},0.45)`;
      ctx.fillRect(x - r * 0.4, y + jy, 1, 1);
    }
  } else if (kind === "soft") {
    stampSoft(ctx, x, y, r, hardness, 1, color);
  } else if (kind === "spray") {
    const { r: cr, g: cg, b: cb } = hexToRgb(color);
    const count = Math.max(6, Math.round(r * 0.9));
    const bias = 0.35 + hardness * 1.5;
    for (let i = 0; i < count; i++) {
      const ang = Math.random() * Math.PI * 2;
      const rad = Math.random() ** bias * r;
      const px = x + Math.cos(ang) * rad;
      const py = y + Math.sin(ang) * rad;
      const al = 0.22 + Math.random() * 0.6;
      ctx.fillStyle = `rgba(${cr},${cg},${cb},${al})`;
      ctx.fillRect(px, py, 1.25, 1.25);
    }
  } else if (kind === "calligraphy") {
    const thin = Math.max(0.7, r * (0.1 + (1 - hardness) * 0.32));
    ctx.translate(x, y);
    ctx.rotate(Math.PI / 4);
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.ellipse(0, 0, r, thin, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (kind === "watercolor") {
    const varied = shiftHue(color, (hashUnit(x * 0.17 + y) - 0.5) * 16);
    stampSoft(ctx, x, y, r * 1.12, 0.02 + hardness * 0.2, 0.13, color);
    const a = hashUnit(x * 12.3 + y) * Math.PI * 2;
    stampSoft(
      ctx,
      x + Math.cos(a) * r * 0.28,
      y + Math.sin(a) * r * 0.28,
      r * 0.82,
      0.05,
      0.08,
      varied,
    );
  } else if (kind === "charcoal") {
    const tone = mixHex(color, "#2a2724", 0.35);
    const { r: cr, g: cg, b: cb } = hexToRgb(tone);
    const n = Math.max(8, Math.round(r * (1.1 + hardness)));
    for (let i = 0; i < n; i++) {
      const ang = hashUnit(x * 3 + y * 7 + i * 13) * Math.PI * 2;
      const rad = Math.sqrt(hashUnit(i * 9 + x + y * 2)) * r;
      const px = x + Math.cos(ang) * rad;
      const py = y + Math.sin(ang) * rad;
      const s = 0.7 + hashUnit(i + px) * Math.max(1, r * 0.16);
      const al = 0.12 + hashUnit(i * 5 + py) * (0.35 + hardness * 0.4);
      ctx.fillStyle = `rgba(${cr},${cg},${cb},${al})`;
      ctx.fillRect(px, py, s, s);
    }
  } else if (kind === "crayon") {
    const { r: cr, g: cg, b: cb } = hexToRgb(color);
    ctx.translate(x, y);
    ctx.rotate(angle);
    const lines = Math.max(3, Math.round(r * 0.85));
    for (let i = 0; i < lines; i++) {
      const yy = (hashUnit(x * 0.2 + i * 17 + y) - 0.5) * 2 * r;
      if (Math.abs(yy) > r) continue;
      if (hashUnit(i * 3 + y + x) < 0.18 * (1 - hardness * 0.5)) continue;
      const half = Math.sqrt(Math.max(0, r * r - yy * yy));
      ctx.strokeStyle = `rgba(${cr},${cg},${cb},${0.32 + hashUnit(i + 4) * 0.55})`;
      ctx.lineWidth = 1 + (i % 2);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(-half, yy);
      ctx.lineTo(half * (0.35 + hashUnit(i + x)), yy);
      ctx.stroke();
    }
  }

  ctx.restore();
}

export function renderBrushPreview(
  canvas: HTMLCanvasElement,
  kind: BrushKind,
  color: string,
  size: number,
  hardness: number,
  opacity: number,
  eraser: boolean,
): void {
  const dpr = Math.min(2, typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1);
  const w = canvas.clientWidth || 280;
  const h = canvas.clientHeight || 72;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#f4efe6";
  ctx.fillRect(0, 0, w, h);

  if (eraser) {
    ctx.strokeStyle = "#c46b7a";
    ctx.lineWidth = 8;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(12, h * 0.72);
    ctx.quadraticCurveTo(w * 0.5, h * 0.15, w - 12, h * 0.62);
    ctx.stroke();
  }

  const radius = Math.max(0.6, Math.min(size / 2, h * 0.4));
  const step = Math.max(1, spacingFor(kind, radius, hardness));
  ctx.save();
  if (eraser) ctx.globalCompositeOperation = "destination-out";
  else ctx.globalAlpha = opacity;
  let prevY = h / 2;
  for (let x = 14; x <= w - 14; x += step) {
    const y = h / 2 + Math.sin((x / w) * Math.PI * 2) * h * 0.22;
    const angle = Math.atan2(y - prevY, step);
    prevY = y;
    drawStamp(ctx, kind, x, y, radius, eraser ? "#000000" : color, hardness, angle);
  }
  ctx.restore();
}
