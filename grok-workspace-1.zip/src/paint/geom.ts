import type { Rect } from "@/paint/flood";
import type { ShapeKind } from "@/paint/types";

export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function clampRect(x: number, y: number, w: number, h: number, cw: number, ch: number): Rect | null {
  const x0 = Math.max(0, Math.floor(x));
  const y0 = Math.max(0, Math.floor(y));
  const x1 = Math.min(cw, Math.ceil(x + w));
  const y1 = Math.min(ch, Math.ceil(y + h));
  if (x1 - x0 < 1 || y1 - y0 < 1) return null;
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

export function unionRect(a: Rect, b: Rect): Rect {
  const x0 = Math.min(a.x, b.x);
  const y0 = Math.min(a.y, b.y);
  const x1 = Math.max(a.x + a.w, b.x + b.w);
  const y1 = Math.max(a.y + a.h, b.y + b.h);
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

export function constrainEnd(
  shape: ShapeKind,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  symmetric: boolean,
): { x1: number; y1: number } {
  if (!symmetric) return { x1, y1 };
  if (shape === "line") {
    const ang = Math.atan2(y1 - y0, x1 - x0);
    const snap = Math.PI / 4;
    const a = Math.round(ang / snap) * snap;
    const dist = Math.hypot(x1 - x0, y1 - y0);
    return { x1: x0 + Math.cos(a) * dist, y1: y0 + Math.sin(a) * dist };
  }
  const dx = x1 - x0;
  const dy = y1 - y0;
  const side = Math.max(Math.abs(dx), Math.abs(dy));
  return {
    x1: x0 + Math.sign(dx || 1) * side,
    y1: y0 + Math.sign(dy || 1) * side,
  };
}

export function drawShape(
  ctx: CanvasRenderingContext2D,
  shape: ShapeKind,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  filled: boolean,
  lineWidth: number,
  color: string,
): void {
  ctx.save();
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = Math.max(1, lineWidth);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  if (shape === "line") {
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1, y1);
    ctx.stroke();
  } else if (shape === "rect") {
    const x = Math.min(x0, x1);
    const y = Math.min(y0, y1);
    const w = Math.abs(x1 - x0);
    const h = Math.abs(y1 - y0);
    if (filled) ctx.fillRect(x, y, w, h);
    else ctx.strokeRect(x, y, w, h);
  } else {
    const rx = Math.max(0.5, Math.abs(x1 - x0) / 2);
    const ry = Math.max(0.5, Math.abs(y1 - y0) / 2);
    ctx.beginPath();
    ctx.ellipse((x0 + x1) / 2, (y0 + y1) / 2, rx, ry, 0, 0, Math.PI * 2);
    if (filled) ctx.fill();
    else ctx.stroke();
  }
  ctx.restore();
}

export function shapeBounds(
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  lineWidth: number,
  cw: number,
  ch: number,
): Rect | null {
  const pad = lineWidth + 4;
  return clampRect(
    Math.min(x0, x1) - pad,
    Math.min(y0, y1) - pad,
    Math.abs(x1 - x0) + pad * 2,
    Math.abs(y1 - y0) + pad * 2,
    cw,
    ch,
  );
}
