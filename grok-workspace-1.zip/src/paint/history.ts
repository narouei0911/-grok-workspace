import type { Rect } from "@/paint/flood";

export type Patch = {
  layerId: string;
  x: number;
  y: number;
  w: number;
  h: number;
  before: ImageData;
  after: ImageData;
};

const MAX_STEPS = 24;
const MAX_BYTES = 72_000_000;

export class History {
  private undoStack: Patch[] = [];
  private redoStack: Patch[] = [];
  private bytes = 0;

  get canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  get canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  push(layerId: string, rect: Rect, before: ImageData, after: ImageData): void {
    const patch: Patch = { layerId, ...rect, before, after };
    this.undoStack.push(patch);
    this.redoStack = [];
    this.bytes += rect.w * rect.h * 8;
    while (this.undoStack.length > MAX_STEPS || (this.bytes > MAX_BYTES && this.undoStack.length > 1)) {
      const old = this.undoStack.shift();
      if (!old) break;
      this.bytes -= old.w * old.h * 8;
    }
  }

  undo(): Patch | null {
    const patch = this.undoStack.pop();
    if (!patch) return null;
    this.redoStack.push(patch);
    return patch;
  }

  redo(): Patch | null {
    const patch = this.redoStack.pop();
    if (!patch) return null;
    this.undoStack.push(patch);
    return patch;
  }

  clear(): void {
    this.undoStack = [];
    this.redoStack = [];
    this.bytes = 0;
  }
}
