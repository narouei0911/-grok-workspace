import type { BrushKind, ShapeKind, Tool, ToolSettings } from "@/paint/types";
import { defaultSettings } from "@/paint/types";

const DB_NAME = "negar";
const STORE = "kv";
const DOC_KEY = "doc";
const PREF_KEY = "negar-prefs-v1";

export type SavedLayer = {
  id: string;
  name: string;
  visible: boolean;
  opacity: number;
  png: Blob;
};

export type SavedReference = {
  png: Blob;
  x: number;
  y: number;
  w: number;
  h: number;
  baseW: number;
  baseH: number;
  rotation: number;
  opacity: number;
  locked: boolean;
};

export type SavedDoc = {
  version: 1;
  artW: number;
  artH: number;
  paper: string;
  hasInk: boolean;
  activeId: string;
  layers: SavedLayer[];
  reference: SavedReference | null;
};

export type Prefs = {
  color: string;
  recent: string[];
  tool: Tool;
  brushKind: BrushKind;
  eraserSoft: boolean;
  shape: ShapeKind;
  filled: boolean;
  symmetric: boolean;
  fillTolerance: number;
  paper: string;
  settings: Record<Tool, ToolSettings>;
};

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("idb"));
  });
}

export async function loadDoc(): Promise<SavedDoc | null> {
  try {
    const db = await openDB();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(DOC_KEY);
      req.onsuccess = () => resolve((req.result as SavedDoc | undefined) ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

export async function saveDoc(doc: SavedDoc): Promise<void> {
  const db = await openDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(doc, DOC_KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export function canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("toBlob"))), "image/png");
  });
}

export function blobToImage(blob: Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("image"));
    };
    img.src = url;
  });
}

export function loadPrefs(): Partial<Prefs> | null {
  try {
    const raw = localStorage.getItem(PREF_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Partial<Prefs>;
  } catch {
    return null;
  }
}

export function savePrefs(prefs: Prefs): void {
  try {
    localStorage.setItem(PREF_KEY, JSON.stringify(prefs));
  } catch {
    /* private mode / quota */
  }
}

export function mergeSettings(partial: Partial<Prefs> | null): Record<Tool, ToolSettings> {
  const base = defaultSettings();
  if (!partial?.settings) return base;
  for (const key of Object.keys(base) as Tool[]) {
    const next = partial.settings[key];
    if (!next) continue;
    base[key] = {
      size: Number.isFinite(next.size) ? next.size : base[key].size,
      opacity: Number.isFinite(next.opacity) ? next.opacity : base[key].opacity,
      hardness: Number.isFinite(next.hardness) ? next.hardness : base[key].hardness,
    };
  }
  return base;
}
