export type Rect = { x: number; y: number; w: number; h: number };

/** Scan-free stack flood fill. Mutates `data` in place. Returns the dirty rect. */
export function floodFill(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  startX: number,
  startY: number,
  fill: readonly [number, number, number, number],
  tolerance: number,
): Rect | null {
  const sx = startX | 0;
  const sy = startY | 0;
  if (sx < 0 || sy < 0 || sx >= width || sy >= height) return null;

  const startI = (sy * width + sx) * 4;
  const sr = data[startI]!;
  const sg = data[startI + 1]!;
  const sb = data[startI + 2]!;
  const sa = data[startI + 3]!;
  const fr = fill[0];
  const fg = fill[1];
  const fb = fill[2];
  const fa = fill[3];

  if (
    Math.abs(sr - fr) <= 1 &&
    Math.abs(sg - fg) <= 1 &&
    Math.abs(sb - fb) <= 1 &&
    Math.abs(sa - fa) <= 1
  ) {
    return null;
  }

  const tol = Math.max(0, tolerance);
  const match = (i: number) =>
    Math.abs(data[i]! - sr) <= tol &&
    Math.abs(data[i + 1]! - sg) <= tol &&
    Math.abs(data[i + 2]! - sb) <= tol &&
    Math.abs(data[i + 3]! - sa) <= tol;

  const seen = new Uint8Array(width * height);
  const stack = new Int32Array(width * height);
  let sp = 0;

  const push = (x: number, y: number) => {
    if (x < 0 || y < 0 || x >= width || y >= height) return;
    const p = y * width + x;
    if (seen[p]) return;
    if (!match(p * 4)) return;
    seen[p] = 1;
    stack[sp++] = p;
  };

  push(sx, sy);
  if (sp === 0) return null;

  let minX = sx;
  let maxX = sx;
  let minY = sy;
  let maxY = sy;

  while (sp > 0) {
    const p = stack[--sp]!;
    const x = p % width;
    const y = (p / width) | 0;
    const i = p * 4;
    data[i] = fr;
    data[i + 1] = fg;
    data[i + 2] = fb;
    data[i + 3] = fa;
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;
    push(x - 1, y);
    push(x + 1, y);
    push(x, y - 1);
    push(x, y + 1);
  }

  return { x: minX, y: minY, w: maxX - minX + 1, h: maxY - minY + 1 };
}
