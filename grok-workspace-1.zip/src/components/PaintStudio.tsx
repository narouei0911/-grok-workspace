import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type ReactNode } from "react";
import {
  Brush,
  ChevronDown,
  ChevronUp,
  Circle,
  Crop,
  Download,
  Droplets,
  Eraser,
  Eye,
  EyeOff,
  Focus,
  Hand,
  ImagePlus,
  Layers,
  Lock,
  LockOpen,
  Menu,
  Minus,
  PaintBucket,
  PenLine,
  Pencil,
  Pipette,
  Redo2,
  SlidersHorizontal,
  SprayCan,
  Square,
  Trash2,
  Undo2,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { renderBrushPreview } from "@/paint/brushes";
import { hexToRgb, hsvToRgb, rgbToHex, rgbToHsv } from "@/paint/color";
import { PaintEngine } from "@/paint/engine";
import {
  ART_PRESETS,
  BRUSH_KINDS,
  PAPERS,
  PIGMENTS,
  defaultSnapshot,
  type BrushKind,
  type ShapeKind,
  type Snapshot,
  type Tool,
} from "@/paint/types";

type Panel =
  | "brush"
  | "pencil"
  | "eraser"
  | "shape"
  | "fill"
  | "color"
  | "ref"
  | "layers"
  | "menu"
  | "help";

type ConfirmState = {
  title: string;
  body: string;
  confirmLabel: string;
  danger?: boolean;
  onYes: () => void;
};

const KIND_ICON: Record<BrushKind, typeof Brush> = {
  hard: Circle,
  soft: Droplets,
  spray: SprayCan,
  calligraphy: PenLine,
  watercolor: Droplets,
  charcoal: Brush,
  crayon: Pencil,
  pencil: Pencil,
};

export function PaintStudio() {
  const studioRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const worldRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<PaintEngine | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const zoomRef = useRef<HTMLSpanElement>(null);
  const [snap, setSnap] = useState<Snapshot>(defaultSnapshot);
  const [panel, setPanel] = useState<Panel | null>(null);
  const [confirm, setConfirm] = useState<ConfirmState | null>(null);
  const [full, setFull] = useState(false);

  useEffect(() => {
    const studio = studioRef.current;
    const stage = stageRef.current;
    const world = worldRef.current;
    if (!studio || !stage || !world) return;
    const engine = new PaintEngine();
    engineRef.current = engine;
    engineHandle = engine;
    const unsub = engine.subscribe(() => setSnap(engine.getSnapshot()));
    engine.onZoom = (scale) => {
      if (zoomRef.current) zoomRef.current.textContent = `${Math.round(scale * 100)}%`;
    };
    engine.attach(studio, stage, world);
    return () => {
      unsub();
      engine.destroy();
      engineHandle = null;
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (zoomRef.current) zoomRef.current.textContent = `${Math.round(snap.zoom * 100)}%`;
  }, [snap.zoom]);

  useEffect(() => {
    const onChange = () => setFull(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  const engine = engineRef.current;

  function toggleTool(tool: Tool, sheet: Panel) {
    if (snap.tool === tool) setPanel(sheet);
    else engineRef.current?.setTool(tool);
  }

  function ask(next: ConfirmState) {
    setConfirm(next);
  }

  const sheetTitle: Record<Panel, string> = {
    brush: "قلم‌مو",
    pencil: "مداد",
    eraser: "پاک‌کن",
    shape: "شکل",
    fill: "سطل رنگ",
    color: "رنگ",
    ref: "عکس مرجع",
    layers: "لایه‌ها",
    menu: "منو",
    help: "حرکت بوم",
  };

  return (
    <div className="studio" ref={studioRef}>
      <div className="stage" ref={stageRef} role="img" aria-label="بوم نقاشی">
        <div className="world" ref={worldRef} />
        {!snap.restoring && !snap.hasInk && !snap.reference && (
          <div className="hint">
            <strong>برای نقاشی انگشت را بکشید</strong>
            <p>دو انگشت بوم را زوم و جابه‌جا می‌کند. عکس مرجع را از نوار پایین اضافه کنید.</p>
          </div>
        )}
        {snap.reference && !snap.reference.locked && panel !== "ref" && (
          <div className="ref-banner">عکس باز است. یک انگشت جابه‌جا می‌کند، دو انگشت اندازه و چرخش. برای نقاشی روی آن، قفل کنید.</div>
        )}
        {snap.message && <div className="toast">{snap.message}</div>}
        {snap.restoring && <div className="restore-veil">در حال باز کردن بوم…</div>}
      </div>

      <header className="topbar">
        <div className="wordmark">نگار</div>
        {snap.savedTick > 0 && <span className="saved-pip" aria-label="ذخیره شد" />}
        <button type="button" className="zoom-btn" onClick={() => engineRef.current?.fit(true)} aria-label="تناسب صفحه">
          <span ref={zoomRef}>100%</span>
        </button>
        <div className="top-actions">
          <button type="button" className="icon-btn" aria-label="واگرد" disabled={!snap.canUndo} onClick={() => engineRef.current?.undo()}>
            <Undo2 size={20} strokeWidth={1.75} />
          </button>
          <button type="button" className="icon-btn" aria-label="ازنو" disabled={!snap.canRedo} onClick={() => engineRef.current?.redo()}>
            <Redo2 size={20} strokeWidth={1.75} />
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label="ذخیره PNG"
            onClick={() => void engineRef.current?.exportPng(true)}
          >
            <Download size={20} strokeWidth={1.75} />
          </button>
          <button type="button" className="icon-btn" aria-label="منو" aria-pressed={panel === "menu"} onClick={() => setPanel(panel === "menu" ? null : "menu")}>
            <Menu size={20} strokeWidth={1.75} />
          </button>
        </div>
      </header>

      <nav className="dock" aria-label="ابزارها">
        <div className="tool-scroller">
          <button type="button" className="tool-btn color-btn" aria-label="رنگ" aria-pressed={panel === "color"} onClick={() => setPanel(panel === "color" ? null : "color")}>
            <span className="color-swatch" style={{ background: snap.color }} />
          </button>
          <ToolButton label="قلم‌مو" pressed={snap.tool === "brush"} onClick={() => toggleTool("brush", "brush")}>
            <Brush size={22} strokeWidth={1.75} />
          </ToolButton>
          <ToolButton label="پاک‌کن" pressed={snap.tool === "eraser"} onClick={() => toggleTool("eraser", "eraser")}>
            <Eraser size={22} strokeWidth={1.75} />
          </ToolButton>
          <ToolButton label="عکس مرجع" pressed={panel === "ref"} hot={!!snap.reference && !snap.reference.locked} onClick={() => setPanel(panel === "ref" ? null : "ref")}>
            <ImagePlus size={22} strokeWidth={1.75} />
            {snap.reference && <span className="ref-dot" />}
          </ToolButton>
          <ToolButton label="تنظیمات ابزار" pressed={panel === "brush" || panel === "pencil" || panel === "eraser" || panel === "shape" || panel === "fill"} onClick={() => openAdjust(snap.tool, setPanel)}>
            <SlidersHorizontal size={22} strokeWidth={1.75} />
          </ToolButton>
          <ToolButton label="تناسب صفحه" onClick={() => engineRef.current?.fit(true)}>
            <Focus size={22} strokeWidth={1.75} />
          </ToolButton>
          <span className="dock-sep" />
          <ToolButton label="مداد" pressed={snap.tool === "pencil"} onClick={() => toggleTool("pencil", "pencil")}>
            <Pencil size={22} strokeWidth={1.75} />
          </ToolButton>
          <ToolButton label="سطل رنگ" pressed={snap.tool === "fill"} onClick={() => toggleTool("fill", "fill")}>
            <PaintBucket size={22} strokeWidth={1.75} />
          </ToolButton>
          <ToolButton label="قطره‌چکان" pressed={snap.tool === "eyedropper"} onClick={() => engineRef.current?.setTool("eyedropper")}>
            <Pipette size={22} strokeWidth={1.75} />
          </ToolButton>
          <ToolButton label="شکل" pressed={snap.tool === "shape"} onClick={() => toggleTool("shape", "shape")}>
            <Square size={22} strokeWidth={1.75} />
          </ToolButton>
          <ToolButton label="انتخاب" pressed={snap.tool === "select"} onClick={() => engineRef.current?.setTool("select")}>
            <Crop size={22} strokeWidth={1.75} />
          </ToolButton>
          <ToolButton label="دست" pressed={snap.tool === "hand"} onClick={() => engineRef.current?.setTool("hand")}>
            <Hand size={22} strokeWidth={1.75} />
          </ToolButton>
          <ToolButton label="لایه‌ها" pressed={panel === "layers"} onClick={() => setPanel(panel === "layers" ? null : "layers")}>
            <Layers size={22} strokeWidth={1.75} />
          </ToolButton>
        </div>
      </nav>

      <Sheet open={panel !== null} title={panel ? sheetTitle[panel] : ""} onClose={() => setPanel(null)}>
        {panel === "color" && engine && (
          <ColorPanel
            color={snap.color}
            recent={snap.recent}
            onChange={(value, commit) => engineRef.current?.setColor(value, commit)}
          />
        )}
        {panel === "brush" && (
          <BrushFields
            snap={snap}
            kind={snap.brushKind}
            onKind={(kind) => engineRef.current?.setBrushKind(kind)}
            eraser={false}
          />
        )}
        {panel === "pencil" && <BrushFields snap={snap} kind="pencil" eraser={false} />}
        {panel === "eraser" && (
          <>
            <div className="seg">
              <button type="button" className="seg-btn" aria-pressed={!snap.eraserSoft} onClick={() => engineRef.current?.setEraserSoft(false)}>
                سخت
              </button>
              <button type="button" className="seg-btn" aria-pressed={snap.eraserSoft} onClick={() => engineRef.current?.setEraserSoft(true)}>
                نرم
              </button>
            </div>
            <BrushFields snap={snap} kind={snap.eraserSoft ? "soft" : "hard"} eraser />
          </>
        )}
        {panel === "shape" && <ShapeFields snap={snap} />}
        {panel === "fill" && (
          <Field label="تلورانس" value={snap.fillTolerance} min={0} max={80} step={1} format={(n) => String(n)} onChange={(n) => engineRef.current?.setFillTolerance(n)} />
        )}
        {panel === "ref" && (
          <RefPanel
            snap={snap}
            onUpload={() => fileRef.current?.click()}
            onDelete={() =>
              ask({
                title: "حذف عکس مرجع؟",
                body: "نقاشی شما می‌ماند. فقط عکس زیر آن حذف می‌شود.",
                confirmLabel: "حذف",
                danger: true,
                onYes: () => engineRef.current?.clearReference(),
              })
            }
          />
        )}
        {panel === "layers" && (
          <LayersPanel
            snap={snap}
            onDelete={(id) =>
              ask({
                title: "حذف لایه؟",
                body: "این کار واگرد ندارد.",
                confirmLabel: "حذف لایه",
                danger: true,
                onYes: () => engineRef.current?.deleteLayer(id),
              })
            }
          />
        )}
        {panel === "menu" && (
          <MenuPanel
            snap={snap}
            full={full}
            onConfirm={ask}
            onClose={() => setPanel(null)}
          />
        )}
        {panel === "help" && (
          <p className="help-copy">
            دو انگشت همیشه بوم را زوم و جابه‌جا می‌کند، از ۵۰٪ تا ۸۰۰٪. ابزار دست با یک انگشت بوم را می‌کشد. چرخ ماوس روی دسکتاپ هم زوم می‌کند. فاصلهٔ صفحه‌کلید دست را موقتاً فعال می‌کند.
          </p>
        )}
      </Sheet>

      {confirm && (
        <div className="modal-root" role="dialog" aria-modal="true" aria-labelledby="confirm-title">
          <div className="modal-card">
            <h2 id="confirm-title">{confirm.title}</h2>
            <p>{confirm.body}</p>
            <div className="modal-actions">
              <button type="button" className="text-btn" onClick={() => setConfirm(null)}>
                انصراف
              </button>
              <button
                type="button"
                className={`text-btn ${confirm.danger ? "danger" : "primary"}`}
                onClick={() => {
                  confirm.onYes();
                  setConfirm(null);
                }}
              >
                {confirm.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        hidden
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (file) void engineRef.current?.loadReference(file);
        }}
      />
    </div>
  );
}

function openAdjust(tool: Tool, setPanel: (panel: Panel) => void) {
  if (tool === "pencil") setPanel("pencil");
  else if (tool === "eraser") setPanel("eraser");
  else if (tool === "shape") setPanel("shape");
  else if (tool === "fill") setPanel("fill");
  else if (tool === "hand" || tool === "select" || tool === "eyedropper") setPanel("help");
  else setPanel("brush");
}

function ToolButton({
  label,
  pressed,
  hot,
  onClick,
  children,
}: {
  label: string;
  pressed?: boolean;
  hot?: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button type="button" className={`tool-btn${hot ? " is-hot" : ""}`} aria-label={label} aria-pressed={pressed} onClick={onClick}>
      {children}
    </button>
  );
}

function Sheet({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div className={`sheet-root${open ? " open" : ""}`} aria-hidden={!open} inert={!open ? true : undefined}>
      <button type="button" className="sheet-backdrop" aria-label="بستن" tabIndex={open ? 0 : -1} onClick={onClose} />
      <div className="sheet" role="dialog" aria-modal="true" aria-label={title}>
        <div className="sheet-handle" />
        <div className="sheet-head">
          <h2>{title}</h2>
          <button type="button" className="icon-btn" aria-label="بستن" onClick={onClose}>
            <X size={18} strokeWidth={1.75} />
          </button>
        </div>
        <div className="sheet-body">{children}</div>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  min,
  max,
  step,
  format,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  format: (value: number) => string;
  onChange: (value: number) => void;
}) {
  return (
    <label className="field">
      <span className="field-label">
        <span>{label}</span>
        <span className="field-value">{format(value)}</span>
      </span>
      <input
        className="slider"
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        aria-label={label}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </label>
  );
}

function StrokePreview({
  kind,
  color,
  size,
  hardness,
  opacity,
  eraser,
}: {
  kind: BrushKind;
  color: string;
  size: number;
  hardness: number;
  opacity: number;
  eraser: boolean;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    renderBrushPreview(canvas, kind, color, size, hardness, opacity, eraser);
  }, [kind, color, size, hardness, opacity, eraser]);
  return <canvas ref={ref} className="stroke-preview" aria-hidden="true" />;
}

function BrushFields({
  snap,
  kind,
  eraser,
  onKind,
}: {
  snap: Snapshot;
  kind: BrushKind;
  eraser: boolean;
  onKind?: (kind: BrushKind) => void;
}) {
  return (
    <>
      <StrokePreview kind={kind} color={snap.color} size={snap.size} hardness={snap.hardness} opacity={snap.opacity} eraser={eraser} />
      {onKind && (
        <div className="kind-grid">
          {BRUSH_KINDS.map((item) => {
            const Icon = KIND_ICON[item.id];
            return (
              <button key={item.id} type="button" className="kind-btn" aria-pressed={snap.brushKind === item.id} onClick={() => onKind(item.id)}>
                <Icon size={18} strokeWidth={1.75} />
                {item.label}
              </button>
            );
          })}
        </div>
      )}
      <Field label="اندازه" value={snap.size} min={1} max={128} step={1} format={(n) => `${n}`} onChange={(n) => live().setSize(n)} />
      <Field label="شفافیت" value={snap.opacity} min={0.05} max={1} step={0.01} format={(n) => `${Math.round(n * 100)}%`} onChange={(n) => live().setOpacity(n)} />
      <Field label="سختی" value={snap.hardness} min={0} max={1} step={0.01} format={(n) => `${Math.round(n * 100)}%`} onChange={(n) => live().setHardness(n)} />
    </>
  );
}

function ShapeFields({ snap }: { snap: Snapshot }) {
  const shapes: { id: ShapeKind; label: string; icon: ReactNode }[] = [
    { id: "line", label: "خط", icon: <Minus size={18} /> },
    { id: "rect", label: "مستطیل", icon: <Square size={18} /> },
    { id: "ellipse", label: "دایره", icon: <Circle size={18} /> },
  ];
  return (
    <>
      <div className="choice-row">
        {shapes.map((shape) => (
          <button key={shape.id} type="button" className="choice-btn" aria-pressed={snap.shape === shape.id} onClick={() => live().setShape(shape.id)}>
            {shape.icon}
            {shape.label}
          </button>
        ))}
      </div>
      <div className="seg seg-gap">
        <button type="button" className="seg-btn" aria-pressed={!snap.filled} onClick={() => live().setFilled(false)}>
          توخالی
        </button>
        <button type="button" className="seg-btn" aria-pressed={snap.filled} onClick={() => live().setFilled(true)}>
          توپر
        </button>
      </div>
      <div className="seg seg-gap">
        <button type="button" className="seg-btn" aria-pressed={!snap.symmetric} onClick={() => live().setSymmetric(false)}>
          آزاد
        </button>
        <button type="button" className="seg-btn" aria-pressed={snap.symmetric} onClick={() => live().setSymmetric(true)}>
          متقارن
        </button>
      </div>
      <Field label="ضخامت خط" value={snap.size} min={1} max={80} step={1} format={(n) => `${n}`} onChange={(n) => live().setSize(n)} />
      <Field label="شفافیت" value={snap.opacity} min={0.05} max={1} step={0.01} format={(n) => `${Math.round(n * 100)}%`} onChange={(n) => live().setOpacity(n)} />
    </>
  );
}

let engineHandle: PaintEngine | null = null;

function live(): PaintEngine {
  if (!engineHandle) throw new Error("engine");
  return engineHandle;
}

function ColorPanel({
  color,
  recent,
  onChange,
}: {
  color: string;
  recent: string[];
  onChange: (color: string, commit: boolean) => void;
}) {
  const rgb = hexToRgb(color);
  const hsv = rgbToHsv(rgb.r, rgb.g, rgb.b);
  const apply = (h: number, s: number, v: number, commit: boolean) => {
    const next = hsvToRgb(h, s, v);
    onChange(rgbToHex(next.r, next.g, next.b), commit);
  };
  const pickPlane = (event: ReactPointerEvent<HTMLDivElement>, commit: boolean) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const s = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
    const v = Math.min(1, Math.max(0, 1 - (event.clientY - rect.top) / rect.height));
    apply(hsv.h, s, v, commit);
  };

  return (
    <>
      <div
        className="sv-plane"
        style={{ background: `hsl(${hsv.h} 100% 50%)` }}
        onPointerDown={(event) => {
          event.currentTarget.setPointerCapture(event.pointerId);
          pickPlane(event, false);
        }}
        onPointerMove={(event) => {
          if (event.currentTarget.hasPointerCapture(event.pointerId)) pickPlane(event, false);
        }}
        onPointerUp={(event) => pickPlane(event, true)}
      >
        <div className="sv-white" />
        <div className="sv-black" />
        <div className="sv-cursor" style={{ left: `${hsv.s * 100}%`, top: `${(1 - hsv.v) * 100}%` }} />
      </div>
      <Field label="طیف" value={hsv.h} min={0} max={360} step={1} format={(n) => `${Math.round(n)}°`} onChange={(n) => apply(n, hsv.s || 1, hsv.v || 1, false)} />
      <div className="section-label">رنگ‌دانه‌ها</div>
      <div className="swatch-row">
        {PIGMENTS.map((pigment) => (
          <button key={pigment} type="button" className="pigment" style={{ background: pigment }} aria-label={pigment} aria-pressed={color.toLowerCase() === pigment} onClick={() => onChange(pigment, true)} />
        ))}
      </div>
      {recent.length > 0 && (
        <>
          <div className="section-label">اخیر</div>
          <div className="swatch-row">
            {recent.map((pigment) => (
              <button key={pigment} type="button" className="pigment" style={{ background: pigment }} aria-label={pigment} aria-pressed={color.toLowerCase() === pigment} onClick={() => onChange(pigment, true)} />
            ))}
          </div>
        </>
      )}
      <div className="hex-line">
        <code>{color.toUpperCase()}</code>
        <input className="native-color" type="color" aria-label="رنگ سیستم" value={safeColorInput(color)} onChange={(event) => onChange(event.target.value, true)} />
      </div>
    </>
  );
}

function safeColorInput(color: string): string {
  return /^#[0-9a-fA-F]{6}$/.test(color) ? color : "#1c1917";
}

function RefPanel({ snap, onUpload, onDelete }: { snap: Snapshot; onUpload: () => void; onDelete: () => void }) {
  const ref = snap.reference;
  return (
    <div className="stack-gap">
      <button type="button" className="text-btn primary" onClick={onUpload}>
        <ImagePlus size={18} />
        انتخاب از گالری
      </button>
      {ref ? (
        <>
          <p className="help-copy">عکس همیشه زیر نقاشی است. قبل از قفل، آن را بکشید. دو انگشت روی خود عکس اندازه و چرخش می‌دهد.</p>
          <Field label="شفافیت عکس" value={ref.opacity} min={0.05} max={1} step={0.01} format={(n) => `${Math.round(n * 100)}%`} onChange={(n) => live().setRefOpacity(n)} />
          <Field label="چرخش" value={Math.round((ref.rotation * 180) / Math.PI)} min={-180} max={180} step={1} format={(n) => `${n}°`} onChange={(n) => live().setRefRotation(n)} />
          <Field label="اندازه" value={ref.scale} min={0.2} max={3} step={0.01} format={(n) => `${Math.round(n * 100)}%`} onChange={(n) => live().setRefScale(n)} />
          <button type="button" className="text-btn" onClick={() => live().setRefLocked(!ref.locked)}>
            {ref.locked ? <LockOpen size={18} /> : <Lock size={18} />}
            {ref.locked ? "باز کردن قفل" : "قفل کردن عکس"}
          </button>
          <button type="button" className="text-btn danger" onClick={onDelete}>
            <Trash2 size={18} />
            حذف عکس
          </button>
        </>
      ) : (
        <p className="help-copy">عکسی را زیر نقاشی بگذارید، شفافیتش را کم کنید و بعد از تنظیم، قفلش کنید تا موقع کشیدن جابه‌جا نشود.</p>
      )}
    </div>
  );
}

function LayersPanel({ snap, onDelete }: { snap: Snapshot; onDelete: (id: string) => void }) {
  const ordered = [...snap.layers].reverse();
  return (
    <div className="stack-gap">
      <button type="button" className="text-btn primary" onClick={() => live().addLayer()}>
        لایهٔ جدید
      </button>
      {ordered.map((layer) => (
        <div key={layer.id} className={`layer-row${layer.active ? " is-active" : ""}`}>
          <button type="button" className="icon-btn" aria-label={layer.visible ? "پنهان کردن" : "نمایش"} onClick={() => live().setLayerVisible(layer.id, !layer.visible)}>
            {layer.visible ? <Eye size={18} /> : <EyeOff size={18} />}
          </button>
          <button type="button" className="layer-name" onClick={() => live().setActiveLayer(layer.id)}>
            {layer.name}
          </button>
          <button type="button" className="icon-btn" aria-label="بردن بالاتر" onClick={() => live().moveLayer(layer.id, 1)}>
            <ChevronUp size={18} />
          </button>
          <button type="button" className="icon-btn" aria-label="بردن پایین‌تر" onClick={() => live().moveLayer(layer.id, -1)}>
            <ChevronDown size={18} />
          </button>
          <button type="button" className="icon-btn" aria-label="حذف لایه" onClick={() => onDelete(layer.id)}>
            <Trash2 size={16} />
          </button>
        </div>
      ))}
      {snap.layers.find((layer) => layer.active) && (
        <Field
          label="شفافیت لایه"
          value={snap.layers.find((layer) => layer.active)?.opacity ?? 1}
          min={0.05}
          max={1}
          step={0.01}
          format={(n) => `${Math.round(n * 100)}%`}
          onChange={(n) => {
            const active = snap.layers.find((layer) => layer.active);
            if (active) live().setLayerOpacity(active.id, n);
          }}
        />
      )}
      <div className="section-label">رنگ کاغذ</div>
      <div className="preset-row">
        {PAPERS.map((paper) => (
          <button key={paper} type="button" className="paper-dot" style={{ background: paper }} aria-label={paper} aria-pressed={snap.paper.toLowerCase() === paper} onClick={() => live().setPaper(paper)} />
        ))}
        <input className="native-color" type="color" aria-label="رنگ کاغذ دلخواه" value={safeColorInput(snap.paper)} onChange={(event) => live().setPaper(event.target.value)} />
      </div>
    </div>
  );
}

function MenuPanel({
  snap,
  full,
  onConfirm,
  onClose,
}: {
  snap: Snapshot;
  full: boolean;
  onConfirm: (state: ConfirmState) => void;
  onClose: () => void;
}) {
  return (
    <div className="menu-block">
      <button type="button" className="text-btn primary" onClick={() => void live().exportPng(true)}>
        <Download size={18} />
        ذخیره PNG با عکس
      </button>
      <button type="button" className="text-btn" onClick={() => void live().exportPng(false)}>
        ذخیره فقط نقاشی
      </button>
      <div className="choice-row">
        <button type="button" className="choice-btn" onClick={() => live().zoomBy(1.25)}>
          <ZoomIn size={18} />
          زوم
        </button>
        <button type="button" className="choice-btn" onClick={() => live().zoomBy(1 / 1.25)}>
          <ZoomOut size={18} />
          کوچک
        </button>
        <button type="button" className="choice-btn" onClick={() => live().fit(true)}>
          <Focus size={18} />
          تناسب
        </button>
      </div>
      <button
        type="button"
        className="text-btn"
        onClick={() => {
          const next = !document.fullscreenElement;
          const action = next ? document.documentElement.requestFullscreen?.() : document.exitFullscreen?.();
          void action?.catch(() => undefined);
        }}
      >
        {full ? "خروج از تمام‌صفحه" : "تمام‌صفحه"}
      </button>
      <div className="section-label">بوم تازه</div>
      <div className="choice-row">
        {ART_PRESETS.map((preset) => (
          <button
            key={preset.id}
            type="button"
            className="choice-btn"
            onClick={() => {
              const run = () => {
                live().newDocument(preset.w, preset.h);
                onClose();
              };
              if (snap.hasInk || snap.reference) {
                onConfirm({
                  title: "بوم تازه؟",
                  body: `اندازه ${preset.label} نقاشی فعلی را جایگزین می‌کند. واگرد آن را برنمی‌گرداند.`,
                  confirmLabel: preset.label,
                  danger: true,
                  onYes: run,
                });
              } else run();
            }}
          >
            {preset.label}
          </button>
        ))}
      </div>
      <button
        type="button"
        className="text-btn danger"
        onClick={() =>
          onConfirm({
            title: "پاک کردن این لایه؟",
            body: "با واگرد می‌توانید برگردانید.",
            confirmLabel: "پاک شود",
            danger: true,
            onYes: () => live().clearLayer(),
          })
        }
      >
        پاک کردن لایه
      </button>
      <button
        type="button"
        className="text-btn danger"
        onClick={() =>
          onConfirm({
            title: "پاک کردن همهٔ لایه‌ها؟",
            body: "کاغذ و عکس مرجع می‌مانند.",
            confirmLabel: "پاک شود",
            danger: true,
            onYes: () => live().clearAll(),
          })
        }
      >
        پاک کردن نقاشی
      </button>
      <p className="help-copy">نقاشی روی همین گوشی موقتاً ذخیره می‌شود تا اگر برنامه بسته شد، برگردد.</p>
    </div>
  );
}
