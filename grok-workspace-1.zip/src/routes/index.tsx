import { createFileRoute } from "@tanstack/react-router";
import { PaintStudio } from "@/components/PaintStudio";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <PaintStudio />;
}
