import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as ChevronUp, C as Eye, D as Download, E as Droplets, M as Brush, O as Crop, S as Focus, T as Eraser, _ as Lock, b as ImagePlus, c as SprayCan, d as Pipette, f as Pencil, g as Menu, h as Minus, i as Undo2, j as ChevronDown, k as Circle, l as SlidersHorizontal, m as PaintBucket, n as ZoomOut, o as Trash2, p as PenLine, r as X, s as Square, t as ZoomIn, u as Redo2, v as LockOpen, w as EyeOff, x as Hand, y as Layers } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CAFGqIie.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function hexToRgb(hex) {
	const h = hex.replace("#", "").trim();
	const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h.padEnd(6, "0").slice(0, 6);
	const n = Number.parseInt(full, 16);
	if (Number.isNaN(n)) return {
		r: 28,
		g: 25,
		b: 23
	};
	return {
		r: n >> 16 & 255,
		g: n >> 8 & 255,
		b: n & 255
	};
}
function rgbToHex(r, g, b) {
	const c = (n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0");
	return `#${c(r)}${c(g)}${c(b)}`;
}
function hsvToRgb(h, s, v) {
	const hh = (h % 360 + 360) % 360;
	const c = v * s;
	const x = c * (1 - Math.abs(hh / 60 % 2 - 1));
	const m = v - c;
	let rp = 0;
	let gp = 0;
	let bp = 0;
	if (hh < 60) [rp, gp, bp] = [
		c,
		x,
		0
	];
	else if (hh < 120) [rp, gp, bp] = [
		x,
		c,
		0
	];
	else if (hh < 180) [rp, gp, bp] = [
		0,
		c,
		x
	];
	else if (hh < 240) [rp, gp, bp] = [
		0,
		x,
		c
	];
	else if (hh < 300) [rp, gp, bp] = [
		x,
		0,
		c
	];
	else [rp, gp, bp] = [
		c,
		0,
		x
	];
	return {
		r: (rp + m) * 255,
		g: (gp + m) * 255,
		b: (bp + m) * 255
	};
}
function rgbToHsv(r, g, b) {
	const rn = r / 255;
	const gn = g / 255;
	const bn = b / 255;
	const max = Math.max(rn, gn, bn);
	const d = max - Math.min(rn, gn, bn);
	let h = 0;
	if (d !== 0) {
		if (max === rn) h = (gn - bn) / d % 6;
		else if (max === gn) h = (bn - rn) / d + 2;
		else h = (rn - gn) / d + 4;
		h *= 60;
		if (h < 0) h += 360;
	}
	return {
		h,
		s: max === 0 ? 0 : d / max,
		v: max
	};
}
function shiftHue(hex, degrees) {
	const { r, g, b } = hexToRgb(hex);
	const hsv = rgbToHsv(r, g, b);
	const next = hsvToRgb(hsv.h + degrees, hsv.s, hsv.v);
	return rgbToHex(next.r, next.g, next.b);
}
function mixHex(a, b, t) {
	const A = hexToRgb(a);
	const B = hexToRgb(b);
	return rgbToHex(A.r + (B.r - A.r) * t, A.g + (B.g - A.g) * t, A.b + (B.b - A.b) * t);
}
function hashUnit(n) {
	const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
	return x - Math.floor(x);
}
function spacingFor(kind, radius, hardness) {
	const r = Math.max(.8, radius);
	switch (kind) {
		case "spray": return Math.max(2, r * .5);
		case "watercolor": return Math.max(2, r * .4);
		case "charcoal": return Math.max(1.2, r * .28);
		case "crayon": return Math.max(1.1, r * .2);
		case "calligraphy": return Math.max(.7, r * .1);
		case "soft": return Math.max(.7, r * (.07 + .14 * (1 - hardness)));
		case "pencil": return Math.max(.45, r * .22);
		default: return Math.max(.5, r * .16);
	}
}
function stampSoft(ctx, x, y, radius, hardness, alpha, color) {
	const r = Math.max(.8, radius);
	const inner = Math.max(0, Math.min(r - .35, r * hardness));
	const g = ctx.createRadialGradient(x, y, inner, x, y, r);
	const { r: cr, g: cg, b: cb } = hexToRgb(color);
	const a = Math.max(0, Math.min(1, alpha));
	g.addColorStop(0, `rgba(${cr | 0},${cg | 0},${cb | 0},${a})`);
	g.addColorStop(1, `rgba(${cr | 0},${cg | 0},${cb | 0},0)`);
	ctx.fillStyle = g;
	ctx.beginPath();
	ctx.arc(x, y, r, 0, Math.PI * 2);
	ctx.fill();
}
function drawStamp(ctx, kind, x, y, radius, color, hardness, angle) {
	const r = Math.max(.4, radius);
	ctx.save();
	ctx.globalAlpha = 1;
	ctx.globalCompositeOperation = "source-over";
	if (kind === "hard") {
		ctx.fillStyle = color;
		ctx.beginPath();
		ctx.arc(x, y, r, 0, Math.PI * 2);
		ctx.fill();
	} else if (kind === "pencil") {
		const jitter = (1 - hardness) * r * .85;
		const jx = (hashUnit(x * 19.1 + y * .37) - .5) * jitter;
		const jy = (hashUnit(y * 13.7 + x * .17) - .5) * jitter;
		ctx.fillStyle = color;
		ctx.beginPath();
		ctx.arc(x + jx, y + jy, Math.max(.35, r * .82), 0, Math.PI * 2);
		ctx.fill();
		if (hashUnit(x * 3.1 + y * 5.7) > .62) {
			const { r: cr, g: cg, b: cb } = hexToRgb(color);
			ctx.fillStyle = `rgba(${cr},${cg},${cb},0.45)`;
			ctx.fillRect(x - r * .4, y + jy, 1, 1);
		}
	} else if (kind === "soft") stampSoft(ctx, x, y, r, hardness, 1, color);
	else if (kind === "spray") {
		const { r: cr, g: cg, b: cb } = hexToRgb(color);
		const count = Math.max(6, Math.round(r * .9));
		const bias = .35 + hardness * 1.5;
		for (let i = 0; i < count; i++) {
			const ang = Math.random() * Math.PI * 2;
			const rad = Math.random() ** bias * r;
			const px = x + Math.cos(ang) * rad;
			const py = y + Math.sin(ang) * rad;
			ctx.fillStyle = `rgba(${cr},${cg},${cb},${.22 + Math.random() * .6})`;
			ctx.fillRect(px, py, 1.25, 1.25);
		}
	} else if (kind === "calligraphy") {
		const thin = Math.max(.7, r * (.1 + (1 - hardness) * .32));
		ctx.translate(x, y);
		ctx.rotate(Math.PI / 4);
		ctx.fillStyle = color;
		ctx.beginPath();
		ctx.ellipse(0, 0, r, thin, 0, 0, Math.PI * 2);
		ctx.fill();
	} else if (kind === "watercolor") {
		const varied = shiftHue(color, (hashUnit(x * .17 + y) - .5) * 16);
		stampSoft(ctx, x, y, r * 1.12, .02 + hardness * .2, .13, color);
		const a = hashUnit(x * 12.3 + y) * Math.PI * 2;
		stampSoft(ctx, x + Math.cos(a) * r * .28, y + Math.sin(a) * r * .28, r * .82, .05, .08, varied);
	} else if (kind === "charcoal") {
		const { r: cr, g: cg, b: cb } = hexToRgb(mixHex(color, "#2a2724", .35));
		const n = Math.max(8, Math.round(r * (1.1 + hardness)));
		for (let i = 0; i < n; i++) {
			const ang = hashUnit(x * 3 + y * 7 + i * 13) * Math.PI * 2;
			const rad = Math.sqrt(hashUnit(i * 9 + x + y * 2)) * r;
			const px = x + Math.cos(ang) * rad;
			const py = y + Math.sin(ang) * rad;
			const s = .7 + hashUnit(i + px) * Math.max(1, r * .16);
			ctx.fillStyle = `rgba(${cr},${cg},${cb},${.12 + hashUnit(i * 5 + py) * (.35 + hardness * .4)})`;
			ctx.fillRect(px, py, s, s);
		}
	} else if (kind === "crayon") {
		const { r: cr, g: cg, b: cb } = hexToRgb(color);
		ctx.translate(x, y);
		ctx.rotate(angle);
		const lines = Math.max(3, Math.round(r * .85));
		for (let i = 0; i < lines; i++) {
			const yy = (hashUnit(x * .2 + i * 17 + y) - .5) * 2 * r;
			if (Math.abs(yy) > r) continue;
			if (hashUnit(i * 3 + y + x) < .18 * (1 - hardness * .5)) continue;
			const half = Math.sqrt(Math.max(0, r * r - yy * yy));
			ctx.strokeStyle = `rgba(${cr},${cg},${cb},${.32 + hashUnit(i + 4) * .55})`;
			ctx.lineWidth = 1 + i % 2;
			ctx.lineCap = "round";
			ctx.beginPath();
			ctx.moveTo(-half, yy);
			ctx.lineTo(half * (.35 + hashUnit(i + x)), yy);
			ctx.stroke();
		}
	}
	ctx.restore();
}
function renderBrushPreview(canvas, kind, color, size, hardness, opacity, eraser) {
	const dpr = Math.min(2, typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1);
	const w = canvas.clientWidth || 280;
	const h = canvas.clientHeight || 72;
	canvas.width = Math.round(w * dpr);
	canvas.height = Math.round(h * dpr);
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	ctx.clearRect(0, 0, w, h);
	ctx.fillStyle = "#f4efe6";
	ctx.fillRect(0, 0, w, h);
	if (eraser) {
		ctx.strokeStyle = "#c46b7a";
		ctx.lineWidth = 8;
		ctx.lineCap = "round";
		ctx.beginPath();
		ctx.moveTo(12, h * .72);
		ctx.quadraticCurveTo(w * .5, h * .15, w - 12, h * .62);
		ctx.stroke();
	}
	const radius = Math.max(.6, Math.min(size / 2, h * .4));
	const step = Math.max(1, spacingFor(kind, radius, hardness));
	ctx.save();
	if (eraser) ctx.globalCompositeOperation = "destination-out";
	else ctx.globalAlpha = opacity;
	let prevY = h / 2;
	for (let x = 14; x <= w - 14; x += step) {
		const y = h / 2 + Math.sin(x / w * Math.PI * 2) * h * .22;
		const angle = Math.atan2(y - prevY, step);
		prevY = y;
		drawStamp(ctx, kind, x, y, radius, eraser ? "#000000" : color, hardness, angle);
	}
	ctx.restore();
}
/** Scan-free stack flood fill. Mutates `data` in place. Returns the dirty rect. */
function floodFill(data, width, height, startX, startY, fill, tolerance) {
	const sx = startX | 0;
	const sy = startY | 0;
	if (sx < 0 || sy < 0 || sx >= width || sy >= height) return null;
	const startI = (sy * width + sx) * 4;
	const sr = data[startI];
	const sg = data[startI + 1];
	const sb = data[startI + 2];
	const sa = data[startI + 3];
	const fr = fill[0];
	const fg = fill[1];
	const fb = fill[2];
	const fa = fill[3];
	if (Math.abs(sr - fr) <= 1 && Math.abs(sg - fg) <= 1 && Math.abs(sb - fb) <= 1 && Math.abs(sa - fa) <= 1) return null;
	const tol = Math.max(0, tolerance);
	const match = (i) => Math.abs(data[i] - sr) <= tol && Math.abs(data[i + 1] - sg) <= tol && Math.abs(data[i + 2] - sb) <= tol && Math.abs(data[i + 3] - sa) <= tol;
	const seen = new Uint8Array(width * height);
	const stack = new Int32Array(width * height);
	let sp = 0;
	const push = (x, y) => {
		if (x < 0 || y < 0 || x >= width || y >= height) return;
		const p = y * width + x;
		if (seen[p]) return;
		if (!match(p * 4)) return;
		seen[p] = 1;
		stack[sp++] = p;
	};
	push(sx, sy);
	if (sp === 0) return null;
	let minX = sx;
	let maxX = sx;
	let minY = sy;
	let maxY = sy;
	while (sp > 0) {
		const p = stack[--sp];
		const x = p % width;
		const y = p / width | 0;
		const i = p * 4;
		data[i] = fr;
		data[i + 1] = fg;
		data[i + 2] = fb;
		data[i + 3] = fa;
		if (x < minX) minX = x;
		if (x > maxX) maxX = x;
		if (y < minY) minY = y;
		if (y > maxY) maxY = y;
		push(x - 1, y);
		push(x + 1, y);
		push(x, y - 1);
		push(x, y + 1);
	}
	return {
		x: minX,
		y: minY,
		w: maxX - minX + 1,
		h: maxY - minY + 1
	};
}
function clamp(n, min, max) {
	return Math.max(min, Math.min(max, n));
}
function clampRect(x, y, w, h, cw, ch) {
	const x0 = Math.max(0, Math.floor(x));
	const y0 = Math.max(0, Math.floor(y));
	const x1 = Math.min(cw, Math.ceil(x + w));
	const y1 = Math.min(ch, Math.ceil(y + h));
	if (x1 - x0 < 1 || y1 - y0 < 1) return null;
	return {
		x: x0,
		y: y0,
		w: x1 - x0,
		h: y1 - y0
	};
}
function unionRect(a, b) {
	const x0 = Math.min(a.x, b.x);
	const y0 = Math.min(a.y, b.y);
	const x1 = Math.max(a.x + a.w, b.x + b.w);
	const y1 = Math.max(a.y + a.h, b.y + b.h);
	return {
		x: x0,
		y: y0,
		w: x1 - x0,
		h: y1 - y0
	};
}
function constrainEnd(shape, x0, y0, x1, y1, symmetric) {
	if (!symmetric) return {
		x1,
		y1
	};
	if (shape === "line") {
		const ang = Math.atan2(y1 - y0, x1 - x0);
		const snap = Math.PI / 4;
		const a = Math.round(ang / snap) * snap;
		const dist = Math.hypot(x1 - x0, y1 - y0);
		return {
			x1: x0 + Math.cos(a) * dist,
			y1: y0 + Math.sin(a) * dist
		};
	}
	const dx = x1 - x0;
	const dy = y1 - y0;
	const side = Math.max(Math.abs(dx), Math.abs(dy));
	return {
		x1: x0 + Math.sign(dx || 1) * side,
		y1: y0 + Math.sign(dy || 1) * side
	};
}
function drawShape(ctx, shape, x0, y0, x1, y1, filled, lineWidth, color) {
	ctx.save();
	ctx.globalAlpha = 1;
	ctx.globalCompositeOperation = "source-over";
	ctx.strokeStyle = color;
	ctx.fillStyle = color;
	ctx.lineWidth = Math.max(1, lineWidth);
	ctx.lineCap = "round";
	ctx.lineJoin = "round";
	if (shape === "line") {
		ctx.beginPath();
		ctx.moveTo(x0, y0);
		ctx.lineTo(x1, y1);
		ctx.stroke();
	} else if (shape === "rect") {
		const x = Math.min(x0, x1);
		const y = Math.min(y0, y1);
		const w = Math.abs(x1 - x0);
		const h = Math.abs(y1 - y0);
		if (filled) ctx.fillRect(x, y, w, h);
		else ctx.strokeRect(x, y, w, h);
	} else {
		const rx = Math.max(.5, Math.abs(x1 - x0) / 2);
		const ry = Math.max(.5, Math.abs(y1 - y0) / 2);
		ctx.beginPath();
		ctx.ellipse((x0 + x1) / 2, (y0 + y1) / 2, rx, ry, 0, 0, Math.PI * 2);
		if (filled) ctx.fill();
		else ctx.stroke();
	}
	ctx.restore();
}
function shapeBounds(x0, y0, x1, y1, lineWidth, cw, ch) {
	const pad = lineWidth + 4;
	return clampRect(Math.min(x0, x1) - pad, Math.min(y0, y1) - pad, Math.abs(x1 - x0) + pad * 2, Math.abs(y1 - y0) + pad * 2, cw, ch);
}
var MAX_STEPS = 24;
var MAX_BYTES = 72e6;
var History = class {
	undoStack = [];
	redoStack = [];
	bytes = 0;
	get canUndo() {
		return this.undoStack.length > 0;
	}
	get canRedo() {
		return this.redoStack.length > 0;
	}
	push(layerId, rect, before, after) {
		const patch = {
			layerId,
			...rect,
			before,
			after
		};
		this.undoStack.push(patch);
		this.redoStack = [];
		this.bytes += rect.w * rect.h * 8;
		while (this.undoStack.length > MAX_STEPS || this.bytes > MAX_BYTES && this.undoStack.length > 1) {
			const old = this.undoStack.shift();
			if (!old) break;
			this.bytes -= old.w * old.h * 8;
		}
	}
	undo() {
		const patch = this.undoStack.pop();
		if (!patch) return null;
		this.redoStack.push(patch);
		return patch;
	}
	redo() {
		const patch = this.redoStack.pop();
		if (!patch) return null;
		this.undoStack.push(patch);
		return patch;
	}
	clear() {
		this.undoStack = [];
		this.redoStack = [];
		this.bytes = 0;
	}
};
var ART_PRESETS = [
	{
		id: "portrait",
		label: "پرتره",
		w: 1080,
		h: 1440
	},
	{
		id: "landscape",
		label: "منظره",
		w: 1440,
		h: 1080
	},
	{
		id: "square",
		label: "مربع",
		w: 1080,
		h: 1080
	},
	{
		id: "large",
		label: "بزرگ",
		w: 1440,
		h: 1920
	}
];
var PIGMENTS = [
	"#1c1917",
	"#f4efe6",
	"#e24b3a",
	"#e07a3d",
	"#f0c14a",
	"#7d9a4e",
	"#2f7d6d",
	"#2a6f97",
	"#3d4e8f",
	"#8a4f86",
	"#c46b7a",
	"#6b4634"
];
var PAPERS = [
	"#f4efe6",
	"#fffdf8",
	"#efe6d6",
	"#d7c4a3",
	"#2a2e33",
	"#1c1917"
];
var BRUSH_KINDS = [
	{
		id: "hard",
		label: "سخت"
	},
	{
		id: "soft",
		label: "نرم"
	},
	{
		id: "spray",
		label: "اسپری"
	},
	{
		id: "calligraphy",
		label: "خوشنویسی"
	},
	{
		id: "watercolor",
		label: "آبرنگ"
	},
	{
		id: "charcoal",
		label: "زغال"
	},
	{
		id: "crayon",
		label: "شمعی"
	}
];
function defaultSettings() {
	return {
		brush: {
			size: 22,
			opacity: 1,
			hardness: .78
		},
		pencil: {
			size: 4,
			opacity: 1,
			hardness: .92
		},
		eraser: {
			size: 28,
			opacity: 1,
			hardness: .7
		},
		fill: {
			size: 24,
			opacity: 1,
			hardness: 1
		},
		eyedropper: {
			size: 12,
			opacity: 1,
			hardness: 1
		},
		shape: {
			size: 6,
			opacity: 1,
			hardness: 1
		},
		select: {
			size: 12,
			opacity: 1,
			hardness: 1
		},
		hand: {
			size: 12,
			opacity: 1,
			hardness: 1
		}
	};
}
function defaultSnapshot() {
	const settings = defaultSettings();
	return {
		ready: false,
		restoring: true,
		tool: "brush",
		color: "#1c1917",
		recent: PIGMENTS.slice(0, 8).map((c) => c),
		size: settings.brush.size,
		opacity: settings.brush.opacity,
		hardness: settings.brush.hardness,
		brushKind: "soft",
		eraserSoft: false,
		shape: "rect",
		filled: false,
		symmetric: false,
		fillTolerance: 22,
		canUndo: false,
		canRedo: false,
		zoom: 1,
		paper: "#f4efe6",
		layers: [],
		reference: null,
		hasInk: false,
		savedTick: 0,
		message: null
	};
}
var DB_NAME = "negar";
var STORE = "kv";
var DOC_KEY = "doc";
var PREF_KEY = "negar-prefs-v1";
function openDB() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("idb"));
	});
}
async function loadDoc() {
	try {
		const db = await openDB();
		return await new Promise((resolve, reject) => {
			const req = db.transaction(STORE, "readonly").objectStore(STORE).get(DOC_KEY);
			req.onsuccess = () => resolve(req.result ?? null);
			req.onerror = () => reject(req.error);
		});
	} catch {
		return null;
	}
}
async function saveDoc(doc) {
	const db = await openDB();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(doc, DOC_KEY);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
function canvasToBlob(canvas) {
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => blob ? resolve(blob) : reject(/* @__PURE__ */ new Error("toBlob")), "image/png");
	});
}
function blobToImage(blob) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(blob);
		const img = new Image();
		img.onload = () => {
			URL.revokeObjectURL(url);
			resolve(img);
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("image"));
		};
		img.src = url;
	});
}
function loadPrefs() {
	try {
		const raw = localStorage.getItem(PREF_KEY);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function savePrefs(prefs) {
	try {
		localStorage.setItem(PREF_KEY, JSON.stringify(prefs));
	} catch {}
}
function mergeSettings(partial) {
	const base = defaultSettings();
	if (!partial?.settings) return base;
	for (const key of Object.keys(base)) {
		const next = partial.settings[key];
		if (!next) continue;
		base[key] = {
			size: Number.isFinite(next.size) ? next.size : base[key].size,
			opacity: Number.isFinite(next.opacity) ? next.opacity : base[key].opacity,
			hardness: Number.isFinite(next.hardness) ? next.hardness : base[key].hardness
		};
	}
	return base;
}
var MIN_ZOOM = .5;
var MAX_ZOOM = 8;
var MAX_LAYERS = 6;
function uid() {
	return `l${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}
function ctx2d(canvas) {
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("canvas");
	return ctx;
}
var PaintEngine = class {
	artW = 1080;
	artH = 1440;
	studio;
	stage;
	world;
	topbar = null;
	dock = null;
	paper;
	refCanvas;
	mask;
	preview;
	overlay;
	chrome;
	snapshot;
	paperCtx;
	refCtx;
	maskCtx;
	previewCtx;
	overlayCtx;
	chromeCtx;
	layers = [];
	active = 0;
	paperColor = "#f4efe6";
	ref = null;
	refBlob = null;
	tool = "brush";
	color = "#1c1917";
	recent = PIGMENTS.slice(0, 8).map((c) => c);
	brushKind = "soft";
	eraserSoft = false;
	shape = "rect";
	filled = false;
	symmetric = false;
	fillTolerance = 22;
	settings = defaultSettings();
	history = new History();
	hasInk = false;
	panX = 0;
	panY = 0;
	scale = 1;
	userMovedView = false;
	lastAspect = 1;
	pointers = /* @__PURE__ */ new Map();
	mode = "idle";
	activePointer = -1;
	refGesture = false;
	pointerIsPen = false;
	drawing = false;
	points = [];
	sx = 0;
	sy = 0;
	hasStamp = false;
	spaceDown = false;
	toolBeforeSpace = null;
	pinch = null;
	panStart = {
		x: 0,
		y: 0,
		sx: 0,
		sy: 0
	};
	refStart = {
		x: 0,
		y: 0,
		px: 0,
		py: 0
	};
	refPinch = null;
	shapeA = null;
	shapeB = null;
	sel = null;
	draft = null;
	selectMode = "none";
	lift = null;
	moveOrigin = null;
	sprayRaf = 0;
	liveRaf = 0;
	saveTimer = 0;
	msgTimer = 0;
	resizeObs = null;
	message = null;
	savedTick = 0;
	restoring = true;
	ready = false;
	destroyed = false;
	restoreGen = 0;
	listeners = /* @__PURE__ */ new Set();
	onZoom = null;
	subscribe(fn) {
		this.listeners.add(fn);
		return () => this.listeners.delete(fn);
	}
	emit() {
		for (const fn of this.listeners) fn();
	}
	getSnapshot() {
		const st = this.settings[this.tool];
		return {
			ready: this.ready,
			restoring: this.restoring,
			tool: this.tool,
			color: this.color,
			recent: this.recent,
			size: st.size,
			opacity: st.opacity,
			hardness: st.hardness,
			brushKind: this.brushKind,
			eraserSoft: this.eraserSoft,
			shape: this.shape,
			filled: this.filled,
			symmetric: this.symmetric,
			fillTolerance: this.fillTolerance,
			canUndo: this.history.canUndo,
			canRedo: this.history.canRedo,
			zoom: this.scale,
			paper: this.paperColor,
			layers: this.layers.map((layer, i) => ({
				id: layer.id,
				name: layer.name,
				visible: layer.visible,
				opacity: layer.opacity,
				active: i === this.active
			})),
			reference: this.ref ? {
				opacity: this.ref.opacity,
				locked: this.ref.locked,
				rotation: this.ref.rotation,
				scale: this.ref.baseW > 0 ? this.ref.w / this.ref.baseW : 1
			} : null,
			hasInk: this.hasInk,
			savedTick: this.savedTick,
			message: this.message
		};
	}
	attach(studio, stage, world) {
		this.studio = studio;
		this.stage = stage;
		this.world = world;
		this.topbar = studio.querySelector(".topbar");
		this.dock = studio.querySelector(".dock");
		this.applyPrefs(loadPrefs());
		this.paper = this.makeCanvas("paper");
		this.refCanvas = this.makeCanvas("ref");
		this.mask = this.makeCanvas("mask");
		this.preview = this.makeCanvas("preview");
		this.overlay = this.makeCanvas("overlay");
		this.chrome = this.makeCanvas("chrome");
		this.snapshot = document.createElement("canvas");
		this.bindContexts();
		this.resizeBacking(this.snapshot);
		world.append(this.paper, this.refCanvas, this.mask, this.preview, this.overlay, this.chrome);
		this.mask.style.visibility = "hidden";
		this.preview.style.visibility = "hidden";
		this.addLayerInternal("لایه ۱");
		this.drawPaper();
		this.orderDom();
		this.bind();
		this.fit(false);
		this.ready = true;
		this.restore();
		this.emit();
	}
	destroy() {
		this.destroyed = true;
		this.restoreGen++;
		cancelAnimationFrame(this.sprayRaf);
		cancelAnimationFrame(this.liveRaf);
		window.clearTimeout(this.saveTimer);
		window.clearTimeout(this.msgTimer);
		this.resizeObs?.disconnect();
		this.stage?.removeEventListener("pointerdown", this.onDown);
		this.stage?.removeEventListener("pointermove", this.onMove);
		this.stage?.removeEventListener("pointerup", this.onUp);
		this.stage?.removeEventListener("pointercancel", this.onUp);
		this.stage?.removeEventListener("wheel", this.onWheel);
		this.stage?.removeEventListener("contextmenu", this.onContext);
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		document.removeEventListener("visibilitychange", this.onVis);
		this.listeners.clear();
	}
	applyPrefs(prefs) {
		if (!prefs) return;
		const tools = [
			"brush",
			"pencil",
			"eraser",
			"fill",
			"eyedropper",
			"shape",
			"select",
			"hand"
		];
		const kinds = [
			"hard",
			"soft",
			"spray",
			"calligraphy",
			"watercolor",
			"charcoal",
			"crayon",
			"pencil"
		];
		const shapes = [
			"line",
			"rect",
			"ellipse"
		];
		if (typeof prefs.color === "string") this.color = prefs.color;
		if (prefs.recent?.length) this.recent = prefs.recent.filter((c) => typeof c === "string").slice(0, 12);
		if (prefs.tool && tools.includes(prefs.tool)) this.tool = prefs.tool;
		if (prefs.brushKind && kinds.includes(prefs.brushKind)) this.brushKind = prefs.brushKind;
		if (typeof prefs.eraserSoft === "boolean") this.eraserSoft = prefs.eraserSoft;
		if (prefs.shape && shapes.includes(prefs.shape)) this.shape = prefs.shape;
		if (typeof prefs.filled === "boolean") this.filled = prefs.filled;
		if (typeof prefs.symmetric === "boolean") this.symmetric = prefs.symmetric;
		if (typeof prefs.fillTolerance === "number") this.fillTolerance = prefs.fillTolerance;
		if (typeof prefs.paper === "string") this.paperColor = prefs.paper;
		this.settings = mergeSettings(prefs);
	}
	makeCanvas(name) {
		const canvas = document.createElement("canvas");
		canvas.className = `c-layer c-${name}`;
		canvas.width = this.artW;
		canvas.height = this.artH;
		return canvas;
	}
	bindContexts() {
		this.paperCtx = ctx2d(this.paper);
		this.refCtx = ctx2d(this.refCanvas);
		this.maskCtx = ctx2d(this.mask);
		this.previewCtx = ctx2d(this.preview);
		this.overlayCtx = ctx2d(this.overlay);
		this.chromeCtx = ctx2d(this.chrome);
	}
	resizeBacking(canvas) {
		canvas.width = this.artW;
		canvas.height = this.artH;
	}
	bind() {
		this.stage.addEventListener("pointerdown", this.onDown, { passive: false });
		this.stage.addEventListener("pointermove", this.onMove, { passive: false });
		this.stage.addEventListener("pointerup", this.onUp);
		this.stage.addEventListener("pointercancel", this.onUp);
		this.stage.addEventListener("wheel", this.onWheel, { passive: false });
		this.stage.addEventListener("contextmenu", this.onContext);
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		document.addEventListener("visibilitychange", this.onVis);
		this.resizeObs = new ResizeObserver(() => this.onResize());
		this.resizeObs.observe(this.stage);
		this.syncCursor();
	}
	onResize = () => {
		const rect = this.stage.getBoundingClientRect();
		const aspect = rect.width / Math.max(1, rect.height);
		if (!this.userMovedView || Math.abs(aspect - this.lastAspect) > .35) this.fit(false);
		this.lastAspect = aspect;
		this.drawChrome();
	};
	insets() {
		return {
			top: this.topbar?.getBoundingClientRect().height ?? 56,
			bottom: this.dock?.getBoundingClientRect().height ?? 76
		};
	}
	fit(_markUser = false) {
		const rect = this.stage.getBoundingClientRect();
		if (rect.width < 8 || rect.height < 8) return;
		const { top, bottom } = this.insets();
		const availW = Math.max(40, rect.width - 28);
		const availH = Math.max(40, rect.height - top - bottom - 20);
		const next = clamp(Math.min(availW / this.artW, availH / this.artH), MIN_ZOOM, MAX_ZOOM);
		this.scale = next;
		this.panX = (rect.width - this.artW * next) / 2;
		this.panY = top + (rect.height - top - bottom - this.artH * next) / 2;
		this.userMovedView = false;
		this.applyView();
		this.onZoom?.(this.scale);
		this.emit();
	}
	zoomBy(factor) {
		const rect = this.stage.getBoundingClientRect();
		const { top, bottom } = this.insets();
		this.zoomAt(rect.width / 2, top + (rect.height - top - bottom) / 2, this.scale * factor);
		this.userMovedView = true;
		this.onZoom?.(this.scale);
		this.emit();
	}
	zoomAt(sx, sy, nextScale) {
		const next = clamp(nextScale, MIN_ZOOM, MAX_ZOOM);
		const cx = (sx - this.panX) / this.scale;
		const cy = (sy - this.panY) / this.scale;
		this.scale = next;
		this.panX = sx - cx * next;
		this.panY = sy - cy * next;
		this.applyView();
		this.drawChrome();
	}
	applyView() {
		this.world.style.width = `${this.artW}px`;
		this.world.style.height = `${this.artH}px`;
		this.world.style.transform = `translate(${this.panX}px, ${this.panY}px) scale(${this.scale})`;
	}
	locate(e) {
		const stage = this.stage.getBoundingClientRect();
		const world = this.world.getBoundingClientRect();
		const sx = e.clientX - stage.left;
		const sy = e.clientY - stage.top;
		const width = world.width || 1;
		const height = world.height || 1;
		return {
			sx,
			sy,
			cx: (e.clientX - world.left) / width * this.artW,
			cy: (e.clientY - world.top) / height * this.artH
		};
	}
	onContext = (e) => {
		e.preventDefault();
	};
	onWheel = (e) => {
		e.preventDefault();
		const pos = this.locate(e);
		const factor = e.deltaY < 0 ? 1.08 : 1 / 1.08;
		this.userMovedView = true;
		this.zoomAt(pos.sx, pos.sy, this.scale * factor);
		this.onZoom?.(this.scale);
	};
	onKeyDown = (e) => {
		const target = e.target;
		const typing = !!target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA");
		const meta = e.metaKey || e.ctrlKey;
		if (meta && e.key.toLowerCase() === "z") {
			e.preventDefault();
			if (e.shiftKey) this.redo();
			else this.undo();
			return;
		}
		if (meta && (e.key.toLowerCase() === "y" || e.shiftKey && e.key.toLowerCase() === "z")) {
			e.preventDefault();
			this.redo();
			return;
		}
		if (typing) return;
		if (e.key === "[") this.setSize(this.settings[this.tool].size - 2);
		if (e.key === "]") this.setSize(this.settings[this.tool].size + 2);
		if (e.key === " " && !this.spaceDown) {
			e.preventDefault();
			this.spaceDown = true;
			this.toolBeforeSpace = this.tool;
			this.setTool("hand");
			return;
		}
		if (meta || e.altKey) return;
		const next = {
			b: "brush",
			n: "pencil",
			e: "eraser",
			g: "fill",
			i: "eyedropper",
			s: "shape",
			v: "select",
			h: "hand"
		}[e.key.toLowerCase()];
		if (next) this.setTool(next);
	};
	onKeyUp = (e) => {
		if (e.key === " " && this.spaceDown) {
			this.spaceDown = false;
			if (this.toolBeforeSpace) this.setTool(this.toolBeforeSpace);
			this.toolBeforeSpace = null;
		}
	};
	onVis = () => {
		if (document.visibilityState === "hidden") this.persist();
	};
	onDown = (e) => {
		if (this.restoring || e.button !== 0) return;
		e.preventDefault();
		this.stage.setPointerCapture(e.pointerId);
		const pos = this.locate(e);
		this.pointers.set(e.pointerId, pos);
		if (this.pointers.size >= 2) {
			const editingRef = this.refGesture && !!this.ref && !this.ref.locked;
			if (!editingRef) this.abortLive();
			if (editingRef) {
				this.mode = "refpinch";
				this.beginRefPinch();
			} else {
				this.mode = "panzoom";
				this.refGesture = false;
				this.beginPinch();
			}
			return;
		}
		this.activePointer = e.pointerId;
		this.pointerIsPen = e.pointerType === "pen";
		const hand = this.tool === "hand" || e.altKey || this.spaceDown;
		if (this.ref && !this.ref.locked && !hand && this.tool !== "eyedropper" && this.hitRef(pos.cx, pos.cy)) {
			this.mode = "refmove";
			this.refGesture = true;
			this.refStart = {
				x: this.ref.x,
				y: this.ref.y,
				px: pos.cx,
				py: pos.cy
			};
			return;
		}
		this.refGesture = false;
		if (hand) {
			this.mode = "pan";
			this.panStart = {
				x: this.panX,
				y: this.panY,
				sx: pos.sx,
				sy: pos.sy
			};
			this.userMovedView = true;
			return;
		}
		if (this.tool === "eyedropper") {
			this.mode = "pick";
			this.pickAt(pos.cx, pos.cy);
			return;
		}
		if (this.tool === "fill") {
			this.mode = "fill";
			this.doFill(pos.cx, pos.cy);
			return;
		}
		if (this.tool === "shape") {
			this.mode = "shape";
			this.shapeA = pos;
			this.shapeB = pos;
			return;
		}
		if (this.tool === "select") {
			this.mode = "select";
			this.beginSelect(pos);
			return;
		}
		this.mode = "draw";
		this.beginStroke(pos.cx, pos.cy, e.pressure);
	};
	onMove = (e) => {
		if (!this.pointers.has(e.pointerId)) return;
		const pos = this.locate(e);
		this.pointers.set(e.pointerId, pos);
		if (this.mode === "panzoom" && this.pointers.size >= 2) {
			this.updatePinch();
			return;
		}
		if (this.mode === "refpinch" && this.pointers.size >= 2) {
			this.updateRefPinch();
			return;
		}
		if (e.pointerId !== this.activePointer) return;
		if (this.mode === "refmove" && this.ref) {
			this.ref.x = this.refStart.x + (pos.cx - this.refStart.px);
			this.ref.y = this.refStart.y + (pos.cy - this.refStart.py);
			this.drawRef();
			return;
		}
		if (this.mode === "pan") {
			this.panX = this.panStart.x + (pos.sx - this.panStart.sx);
			this.panY = this.panStart.y + (pos.sy - this.panStart.sy);
			this.applyView();
			return;
		}
		if (this.mode === "draw" && this.drawing) {
			const events = e.getCoalescedEvents?.() ?? [e];
			for (const ev of events) {
				const p = this.locate(ev);
				this.points.push({
					x: p.cx,
					y: p.cy,
					p: ev.pressure
				});
				this.advance(p.cx, p.cy, ev.pressure || 0);
			}
			this.schedulePreview();
			return;
		}
		if (this.mode === "shape") {
			this.shapeB = pos;
			this.paintShapeOverlay();
			return;
		}
		if (this.mode === "select") {
			this.updateSelect(pos);
			return;
		}
		if (this.mode === "pick") this.pickAt(pos.cx, pos.cy);
	};
	onUp = (e) => {
		this.pointers.delete(e.pointerId);
		if (this.mode === "panzoom" || this.mode === "refpinch") {
			if (this.pointers.size < 2) {
				if (this.mode === "refpinch") this.scheduleSave();
				this.mode = "idle";
				this.refGesture = false;
				this.pinch = null;
				this.refPinch = null;
				this.emit();
			}
			return;
		}
		if (this.pointers.size > 0) return;
		if (this.mode === "draw") this.commitStroke();
		else if (this.mode === "shape") this.commitShape();
		else if (this.mode === "select") this.endSelect();
		else if (this.mode === "refmove") {
			this.scheduleSave();
			this.emit();
		} else if (this.mode === "pick") {
			this.rememberColor();
			this.emit();
		}
		this.mode = "idle";
		this.refGesture = false;
		this.shapeA = null;
	};
	beginPinch() {
		const pts = [...this.pointers.values()];
		if (pts.length < 2) return;
		const dist = Math.hypot(pts[0].sx - pts[1].sx, pts[0].sy - pts[1].sy) || 1;
		const midX = (pts[0].sx + pts[1].sx) / 2;
		const midY = (pts[0].sy + pts[1].sy) / 2;
		this.pinch = {
			dist,
			scale: this.scale,
			ax: (midX - this.panX) / this.scale,
			ay: (midY - this.panY) / this.scale
		};
		this.userMovedView = true;
	}
	updatePinch() {
		const pts = [...this.pointers.values()];
		if (pts.length < 2 || !this.pinch) return;
		const dist = Math.hypot(pts[0].sx - pts[1].sx, pts[0].sy - pts[1].sy) || 1;
		const midX = (pts[0].sx + pts[1].sx) / 2;
		const midY = (pts[0].sy + pts[1].sy) / 2;
		const next = clamp(this.pinch.scale * (dist / this.pinch.dist), MIN_ZOOM, MAX_ZOOM);
		this.scale = next;
		this.panX = midX - this.pinch.ax * next;
		this.panY = midY - this.pinch.ay * next;
		this.applyView();
		this.drawChrome();
		this.onZoom?.(this.scale);
	}
	beginRefPinch() {
		if (!this.ref) return;
		const pts = [...this.pointers.values()];
		if (pts.length < 2) return;
		this.refPinch = {
			dist: Math.hypot(pts[0].cx - pts[1].cx, pts[0].cy - pts[1].cy) || 1,
			ang: Math.atan2(pts[1].cy - pts[0].cy, pts[1].cx - pts[0].cx),
			w: this.ref.w,
			h: this.ref.h,
			rot: this.ref.rotation,
			cx: this.ref.x + this.ref.w / 2,
			cy: this.ref.y + this.ref.h / 2,
			midX: (pts[0].cx + pts[1].cx) / 2,
			midY: (pts[0].cy + pts[1].cy) / 2
		};
	}
	updateRefPinch() {
		if (!this.ref || !this.refPinch) return;
		const pts = [...this.pointers.values()];
		if (pts.length < 2) return;
		const dist = Math.hypot(pts[0].cx - pts[1].cx, pts[0].cy - pts[1].cy) || 1;
		const ang = Math.atan2(pts[1].cy - pts[0].cy, pts[1].cx - pts[0].cx);
		const midX = (pts[0].cx + pts[1].cx) / 2;
		const midY = (pts[0].cy + pts[1].cy) / 2;
		const s = clamp(dist / this.refPinch.dist, .15, 6);
		this.ref.w = Math.max(36, this.refPinch.w * s);
		this.ref.h = Math.max(36, this.refPinch.h * s);
		this.ref.rotation = this.refPinch.rot + (ang - this.refPinch.ang);
		const cx = this.refPinch.cx + (midX - this.refPinch.midX);
		const cy = this.refPinch.cy + (midY - this.refPinch.midY);
		this.ref.x = cx - this.ref.w / 2;
		this.ref.y = cy - this.ref.h / 2;
		this.drawRef();
	}
	hitRef(x, y) {
		if (!this.ref) return false;
		const cx = this.ref.x + this.ref.w / 2;
		const cy = this.ref.y + this.ref.h / 2;
		const dx = x - cx;
		const dy = y - cy;
		const cos = Math.cos(-this.ref.rotation);
		const sin = Math.sin(-this.ref.rotation);
		const lx = dx * cos - dy * sin;
		const ly = dx * sin + dy * cos;
		return Math.abs(lx) <= this.ref.w / 2 && Math.abs(ly) <= this.ref.h / 2;
	}
	abortLive() {
		if (this.mode === "draw") this.cancelStroke();
		if (this.mode === "shape") {
			this.clearCanvas(this.overlay);
			this.overlay.style.visibility = "hidden";
		}
		if (this.mode === "select" && this.selectMode === "move") {
			this.preview.style.visibility = "hidden";
			this.showActiveLayer();
			if (this.sel) {
				this.sel.dx = 0;
				this.sel.dy = 0;
			}
		}
		this.draft = null;
		this.selectMode = "none";
		this.drawing = false;
		cancelAnimationFrame(this.sprayRaf);
		this.sprayRaf = 0;
		this.drawChrome();
	}
	activeLayer() {
		return this.layers[this.active] ?? this.layers[0];
	}
	drawKind() {
		if (this.tool === "pencil") return "pencil";
		if (this.tool === "eraser") return this.eraserSoft ? "soft" : "hard";
		if (this.tool === "brush") return this.brushKind;
		return "hard";
	}
	isEraser() {
		return this.tool === "eraser";
	}
	radius(pressure) {
		const base = Math.max(.5, this.settings[this.tool].size / 2);
		if (this.pointerIsPen) return Math.max(.4, base * (.2 + .8 * (pressure > 0 ? pressure : .5)));
		return base;
	}
	beginStroke(x, y, pressure) {
		const layer = this.activeLayer();
		if (!layer.visible) {
			layer.visible = true;
			this.syncLayerStyles();
		}
		this.drawing = true;
		this.points = [{
			x,
			y,
			p: pressure
		}];
		this.hasStamp = false;
		if (this.isEraser()) this.copyLayerTo(this.snapshot, layer);
		this.clearCanvas(this.mask);
		if (this.isEraser()) {
			this.mask.style.visibility = "hidden";
			this.preview.style.visibility = "visible";
			this.preview.style.opacity = String(layer.opacity);
			layer.canvas.style.visibility = "hidden";
		} else {
			this.preview.style.visibility = "hidden";
			this.mask.style.visibility = "visible";
			this.mask.style.opacity = String(this.settings[this.tool].opacity * layer.opacity);
		}
		this.advance(x, y, pressure);
		if (this.drawKind() === "spray") this.loopSpray();
		if (this.isEraser()) this.renderEraserPreview();
	}
	advance(x, y, pressure) {
		const radius = this.radius(pressure);
		if (!this.hasStamp) {
			this.emitStamp(x, y, radius, 0);
			this.sx = x;
			this.sy = y;
			this.hasStamp = true;
			return;
		}
		const dx = x - this.sx;
		const dy = y - this.sy;
		const dist = Math.hypot(dx, dy);
		const step = spacingFor(this.drawKind(), radius, this.settings[this.tool].hardness);
		if (dist < step) return;
		const angle = Math.atan2(dy, dx);
		const steps = Math.floor(dist / step);
		for (let i = 1; i <= steps; i++) {
			const t = i * step / dist;
			this.emitStamp(this.sx + dx * t, this.sy + dy * t, radius, angle);
		}
		const used = steps * step;
		this.sx += dx / dist * used;
		this.sy += dy / dist * used;
	}
	emitStamp(x, y, radius, angle) {
		drawStamp(this.maskCtx, this.drawKind(), x, y, radius, this.isEraser() ? "#000000" : this.color, this.settings[this.tool].hardness, angle);
	}
	loopSpray() {
		if (this.sprayRaf) return;
		const tick = () => {
			if (!this.drawing || this.drawKind() !== "spray") {
				this.sprayRaf = 0;
				return;
			}
			const last = this.points[this.points.length - 1];
			if (last) this.emitStamp(last.x, last.y, this.radius(last.p), 0);
			this.sprayRaf = requestAnimationFrame(tick);
		};
		this.sprayRaf = requestAnimationFrame(tick);
	}
	schedulePreview() {
		if (!this.isEraser() || this.liveRaf) return;
		this.liveRaf = requestAnimationFrame(() => {
			this.liveRaf = 0;
			if (this.drawing && this.isEraser()) this.renderEraserPreview();
		});
	}
	renderEraserPreview() {
		const ctx = this.previewCtx;
		ctx.setTransform(1, 0, 0, 1, 0, 0);
		ctx.globalAlpha = 1;
		ctx.globalCompositeOperation = "source-over";
		ctx.clearRect(0, 0, this.artW, this.artH);
		ctx.drawImage(this.snapshot, 0, 0);
		ctx.globalAlpha = this.settings.eraser.opacity;
		ctx.globalCompositeOperation = "destination-out";
		ctx.drawImage(this.mask, 0, 0);
		ctx.globalAlpha = 1;
		ctx.globalCompositeOperation = "source-over";
	}
	strokeBounds() {
		let minX = Infinity;
		let minY = Infinity;
		let maxX = -Infinity;
		let maxY = -Infinity;
		for (const p of this.points) {
			if (p.x < minX) minX = p.x;
			if (p.y < minY) minY = p.y;
			if (p.x > maxX) maxX = p.x;
			if (p.y > maxY) maxY = p.y;
		}
		if (!Number.isFinite(minX)) return null;
		const pad = this.settings[this.tool].size * 1.8 + 24;
		return clampRect(minX - pad, minY - pad, maxX - minX + pad * 2, maxY - minY + pad * 2, this.artW, this.artH);
	}
	commitStroke() {
		if (!this.drawing) return;
		this.drawing = false;
		cancelAnimationFrame(this.sprayRaf);
		this.sprayRaf = 0;
		const layer = this.activeLayer();
		const rect = this.strokeBounds();
		try {
			if (!rect) return;
			const before = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
			layer.ctx.save();
			layer.ctx.globalAlpha = this.settings[this.tool].opacity;
			layer.ctx.globalCompositeOperation = this.isEraser() ? "destination-out" : "source-over";
			layer.ctx.drawImage(this.mask, 0, 0);
			layer.ctx.restore();
			const after = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
			this.history.push(layer.id, rect, before, after);
			this.hasInk = true;
			if (!this.isEraser()) this.rememberColor();
			this.scheduleSave();
		} finally {
			this.showActiveLayer();
			this.clearCanvas(this.mask);
			this.emit();
		}
	}
	cancelStroke() {
		this.drawing = false;
		cancelAnimationFrame(this.sprayRaf);
		this.sprayRaf = 0;
		this.showActiveLayer();
		this.clearCanvas(this.mask);
	}
	showActiveLayer() {
		const layer = this.activeLayer();
		this.preview.style.visibility = "hidden";
		this.mask.style.visibility = "hidden";
		layer.canvas.style.visibility = layer.visible ? "visible" : "hidden";
	}
	paintShapeOverlay() {
		if (!this.shapeA || !this.shapeB) return;
		const end = constrainEnd(this.shape, this.shapeA.cx, this.shapeA.cy, this.shapeB.cx, this.shapeB.cy, this.symmetric);
		this.clearCanvas(this.overlay);
		drawShape(this.overlayCtx, this.shape, this.shapeA.cx, this.shapeA.cy, end.x1, end.y1, this.filled, this.settings.shape.size, this.color);
		const layer = this.activeLayer();
		this.overlay.style.visibility = "visible";
		this.overlay.style.opacity = String(this.settings.shape.opacity * layer.opacity);
	}
	commitShape() {
		if (!this.shapeA || !this.shapeB) return;
		const end = constrainEnd(this.shape, this.shapeA.cx, this.shapeA.cy, this.shapeB.cx, this.shapeB.cy, this.symmetric);
		const rect = shapeBounds(this.shapeA.cx, this.shapeA.cy, end.x1, end.y1, this.filled ? 2 : this.settings.shape.size, this.artW, this.artH);
		this.clearCanvas(this.overlay);
		this.overlay.style.visibility = "hidden";
		if (!rect) return;
		if (Math.hypot(end.x1 - this.shapeA.cx, end.y1 - this.shapeA.cy) < 1) return;
		const layer = this.activeLayer();
		const before = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
		this.clearCanvas(this.mask);
		drawShape(this.maskCtx, this.shape, this.shapeA.cx, this.shapeA.cy, end.x1, end.y1, this.filled, this.settings.shape.size, this.color);
		layer.ctx.save();
		layer.ctx.globalAlpha = this.settings.shape.opacity;
		layer.ctx.drawImage(this.mask, 0, 0);
		layer.ctx.restore();
		this.clearCanvas(this.mask);
		const after = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
		this.history.push(layer.id, rect, before, after);
		this.hasInk = true;
		this.rememberColor();
		this.scheduleSave();
		this.emit();
	}
	doFill(x, y) {
		const ix = x | 0;
		const iy = y | 0;
		if (ix < 0 || iy < 0 || ix >= this.artW || iy >= this.artH) return;
		const layer = this.activeLayer();
		if (!layer.visible) {
			layer.visible = true;
			this.syncLayerStyles();
		}
		const img = layer.ctx.getImageData(0, 0, this.artW, this.artH);
		const { r, g, b } = hexToRgb(this.color);
		const alpha = Math.round(this.settings.fill.opacity * 255);
		const beforeFull = new ImageData(new Uint8ClampedArray(img.data), this.artW, this.artH);
		const box = floodFill(img.data, this.artW, this.artH, ix, iy, [
			r,
			g,
			b,
			alpha
		], this.fillTolerance);
		if (!box) return;
		const before = sliceImage(beforeFull, box);
		layer.ctx.putImageData(img, 0, 0);
		const after = layer.ctx.getImageData(box.x, box.y, box.w, box.h);
		this.history.push(layer.id, box, before, after);
		this.hasInk = true;
		this.rememberColor();
		this.scheduleSave();
		this.emit();
	}
	pickAt(x, y) {
		const ix = x | 0;
		const iy = y | 0;
		if (ix < 0 || iy < 0 || ix >= this.artW || iy >= this.artH) return;
		let dst = {
			...hexToRgb(this.paperColor),
			a: 1
		};
		const over = (src) => {
			const ia = 1 - src.a;
			dst = {
				r: src.r * src.a + dst.r * ia,
				g: src.g * src.a + dst.g * ia,
				b: src.b * src.a + dst.b * ia,
				a: src.a + dst.a * ia
			};
		};
		const sample = (canvas) => {
			const data = ctx2d(canvas).getImageData(ix, iy, 1, 1).data;
			return {
				r: data[0],
				g: data[1],
				b: data[2],
				a: data[3] / 255
			};
		};
		const refPx = sample(this.refCanvas);
		if (refPx.a > .004) over(refPx);
		for (const layer of this.layers) {
			if (!layer.visible) continue;
			const px = sample(layer.canvas);
			const a = px.a * layer.opacity;
			if (a < .004) continue;
			over({
				r: px.r,
				g: px.g,
				b: px.b,
				a
			});
		}
		this.color = rgbToHex(dst.r, dst.g, dst.b);
		this.emit();
	}
	beginSelect(pos) {
		if (this.sel && pointIn(pos.cx, pos.cy, this.sel.x + this.sel.dx, this.sel.y + this.sel.dy, this.sel.w, this.sel.h)) {
			this.selectMode = "move";
			this.prepareMove(pos);
			return;
		}
		this.sel = null;
		this.selectMode = "marquee";
		this.moveOrigin = pos;
		this.draft = {
			x: pos.cx,
			y: pos.cy,
			w: 0,
			h: 0
		};
		this.drawChrome();
	}
	prepareMove(pos) {
		if (!this.sel) return;
		const layer = this.activeLayer();
		this.copyLayerTo(this.snapshot, layer);
		const c = document.createElement("canvas");
		const w = Math.max(1, Math.ceil(this.sel.w));
		const h = Math.max(1, Math.ceil(this.sel.h));
		c.width = w;
		c.height = h;
		ctx2d(c).drawImage(layer.canvas, this.sel.x, this.sel.y, this.sel.w, this.sel.h, 0, 0, w, h);
		this.lift = c;
		this.sel.dx = 0;
		this.sel.dy = 0;
		this.moveOrigin = pos;
		this.preview.style.visibility = "visible";
		this.preview.style.opacity = String(layer.opacity);
		layer.canvas.style.visibility = "hidden";
		this.renderSelectionPreview();
	}
	updateSelect(pos) {
		if (this.selectMode === "marquee" && this.moveOrigin) {
			const x = Math.min(this.moveOrigin.cx, pos.cx);
			const y = Math.min(this.moveOrigin.cy, pos.cy);
			this.draft = {
				x,
				y,
				w: Math.abs(pos.cx - this.moveOrigin.cx),
				h: Math.abs(pos.cy - this.moveOrigin.cy)
			};
			this.drawChrome();
			return;
		}
		if (this.selectMode === "move" && this.sel && this.moveOrigin) {
			this.sel.dx = pos.cx - this.moveOrigin.cx;
			this.sel.dy = pos.cy - this.moveOrigin.cy;
			this.renderSelectionPreview();
			this.drawChrome();
		}
	}
	renderSelectionPreview() {
		if (!this.sel || !this.lift) return;
		const ctx = this.previewCtx;
		ctx.setTransform(1, 0, 0, 1, 0, 0);
		ctx.globalAlpha = 1;
		ctx.globalCompositeOperation = "source-over";
		ctx.clearRect(0, 0, this.artW, this.artH);
		ctx.drawImage(this.snapshot, 0, 0);
		ctx.clearRect(this.sel.x, this.sel.y, this.sel.w, this.sel.h);
		ctx.drawImage(this.lift, this.sel.x + this.sel.dx, this.sel.y + this.sel.dy);
	}
	endSelect() {
		if (this.selectMode === "marquee" && this.draft && this.draft.w > 4 && this.draft.h > 4) {
			const rect = clampRect(this.draft.x, this.draft.y, this.draft.w, this.draft.h, this.artW, this.artH);
			this.sel = rect ? {
				...rect,
				dx: 0,
				dy: 0
			} : null;
		}
		if (this.selectMode === "move" && this.sel && (this.sel.dx !== 0 || this.sel.dy !== 0)) this.commitMove();
		else if (this.selectMode === "move") {
			this.preview.style.visibility = "hidden";
			this.showActiveLayer();
		}
		this.draft = null;
		this.selectMode = "none";
		this.drawChrome();
		this.emit();
	}
	commitMove() {
		if (!this.sel || !this.lift) return;
		const layer = this.activeLayer();
		const next = clampRect(this.sel.x + this.sel.dx, this.sel.y + this.sel.dy, this.sel.w, this.sel.h, this.artW, this.artH);
		const prev = clampRect(this.sel.x, this.sel.y, this.sel.w, this.sel.h, this.artW, this.artH);
		const rect = prev && next ? unionRect(prev, next) : prev || next;
		if (!rect) return;
		const before = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
		layer.ctx.save();
		layer.ctx.beginPath();
		layer.ctx.rect(rect.x, rect.y, rect.w, rect.h);
		layer.ctx.clip();
		layer.ctx.clearRect(rect.x, rect.y, rect.w, rect.h);
		layer.ctx.drawImage(this.preview, 0, 0);
		layer.ctx.restore();
		const after = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
		this.history.push(layer.id, rect, before, after);
		this.sel.x += this.sel.dx;
		this.sel.y += this.sel.dy;
		this.sel.dx = 0;
		this.sel.dy = 0;
		this.hasInk = true;
		this.preview.style.visibility = "hidden";
		this.showActiveLayer();
		this.scheduleSave();
	}
	copyLayerTo(dest, layer) {
		if (dest.width !== this.artW || dest.height !== this.artH) this.resizeBacking(dest);
		const ctx = ctx2d(dest);
		ctx.setTransform(1, 0, 0, 1, 0, 0);
		ctx.globalAlpha = 1;
		ctx.globalCompositeOperation = "source-over";
		ctx.clearRect(0, 0, this.artW, this.artH);
		ctx.drawImage(layer.canvas, 0, 0);
	}
	clearCanvas(canvas) {
		const ctx = ctx2d(canvas);
		ctx.setTransform(1, 0, 0, 1, 0, 0);
		ctx.globalAlpha = 1;
		ctx.globalCompositeOperation = "source-over";
		ctx.clearRect(0, 0, canvas.width, canvas.height);
	}
	orderDom() {
		const nodes = [this.paper, this.refCanvas];
		this.layers.forEach((layer, i) => {
			nodes.push(layer.canvas);
			if (i === this.active) nodes.push(this.preview, this.mask, this.overlay);
		});
		nodes.push(this.chrome);
		for (const node of nodes) this.world.appendChild(node);
	}
	syncLayerStyles() {
		for (const layer of this.layers) {
			layer.canvas.style.opacity = String(layer.opacity);
			if (layer.canvas.style.visibility !== "hidden" || layer !== this.activeLayer() || !this.drawing) layer.canvas.style.visibility = layer.visible ? "visible" : "hidden";
		}
	}
	drawPaper() {
		this.paperCtx.setTransform(1, 0, 0, 1, 0, 0);
		this.paperCtx.globalAlpha = 1;
		this.paperCtx.fillStyle = this.paperColor;
		this.paperCtx.fillRect(0, 0, this.artW, this.artH);
	}
	drawRef() {
		this.clearCanvas(this.refCanvas);
		if (this.ref) {
			this.refCtx.save();
			this.refCtx.globalAlpha = this.ref.opacity;
			this.refCtx.imageSmoothingEnabled = true;
			this.refCtx.imageSmoothingQuality = "high";
			this.refCtx.translate(this.ref.x + this.ref.w / 2, this.ref.y + this.ref.h / 2);
			this.refCtx.rotate(this.ref.rotation);
			this.refCtx.drawImage(this.ref.source, -this.ref.w / 2, -this.ref.h / 2, this.ref.w, this.ref.h);
			this.refCtx.restore();
		}
		this.drawChrome();
	}
	drawChrome() {
		this.clearCanvas(this.chrome);
		const ctx = this.chromeCtx;
		const lw = 1.5 / this.scale;
		if (this.ref && !this.ref.locked) {
			ctx.save();
			ctx.translate(this.ref.x + this.ref.w / 2, this.ref.y + this.ref.h / 2);
			ctx.rotate(this.ref.rotation);
			ctx.strokeStyle = "rgba(224,122,61,0.95)";
			ctx.lineWidth = 2 / this.scale;
			ctx.setLineDash([8 / this.scale, 6 / this.scale]);
			ctx.strokeRect(-this.ref.w / 2, -this.ref.h / 2, this.ref.w, this.ref.h);
			ctx.restore();
		}
		const live = this.draft ?? (this.sel ? {
			x: this.sel.x + this.sel.dx,
			y: this.sel.y + this.sel.dy,
			w: this.sel.w,
			h: this.sel.h
		} : null);
		if (this.tool === "select" && live && live.w > 1 && live.h > 1) {
			ctx.save();
			ctx.strokeStyle = "#e07a3d";
			ctx.lineWidth = lw;
			ctx.setLineDash([6 / this.scale, 4 / this.scale]);
			ctx.strokeRect(live.x, live.y, live.w, live.h);
			ctx.restore();
		}
	}
	createLayer(name, id = uid()) {
		const canvas = this.makeCanvas("paint");
		const layer = {
			id,
			name,
			canvas,
			ctx: ctx2d(canvas),
			visible: true,
			opacity: 1
		};
		canvas.style.opacity = "1";
		return layer;
	}
	addLayerInternal(name) {
		const layer = this.createLayer(name);
		this.layers.push(layer);
		this.active = this.layers.length - 1;
		this.orderDom();
	}
	rebuildWorld(w, h) {
		this.artW = w;
		this.artH = h;
		for (const canvas of [
			this.paper,
			this.refCanvas,
			this.mask,
			this.preview,
			this.overlay,
			this.chrome,
			this.snapshot
		]) this.resizeBacking(canvas);
		this.bindContexts();
		for (const layer of this.layers) layer.canvas.remove();
		this.layers = [];
		this.history.clear();
		this.sel = null;
		this.drawPaper();
	}
	setTool(tool) {
		if (this.tool === "select" && tool !== "select") {
			this.sel = null;
			this.draft = null;
			this.drawChrome();
		}
		this.tool = tool;
		this.syncCursor();
		this.persistPrefs();
		this.emit();
	}
	setColor(color, remember = false) {
		this.color = color;
		if (remember) this.rememberColor();
		this.emit();
	}
	setSize(size) {
		this.settings[this.tool].size = clamp(Math.round(size), 1, 160);
		this.persistPrefs();
		this.emit();
	}
	setOpacity(opacity) {
		this.settings[this.tool].opacity = clamp(opacity, .02, 1);
		this.persistPrefs();
		this.emit();
	}
	setHardness(hardness) {
		this.settings[this.tool].hardness = clamp(hardness, 0, 1);
		this.persistPrefs();
		this.emit();
	}
	setBrushKind(kind) {
		this.brushKind = kind;
		if (this.tool !== "brush") this.setTool("brush");
		else {
			this.persistPrefs();
			this.emit();
		}
	}
	setEraserSoft(soft) {
		this.eraserSoft = soft;
		this.persistPrefs();
		this.emit();
	}
	setShape(shape) {
		this.shape = shape;
		if (this.tool !== "shape") this.tool = "shape";
		this.syncCursor();
		this.persistPrefs();
		this.emit();
	}
	setFilled(filled) {
		this.filled = filled;
		this.persistPrefs();
		this.emit();
	}
	setSymmetric(symmetric) {
		this.symmetric = symmetric;
		this.persistPrefs();
		this.emit();
	}
	setFillTolerance(tolerance) {
		this.fillTolerance = clamp(Math.round(tolerance), 0, 90);
		this.persistPrefs();
		this.emit();
	}
	setPaper(color) {
		this.paperColor = color;
		this.drawPaper();
		this.persistPrefs();
		this.scheduleSave();
		this.emit();
	}
	undo() {
		if (this.drawing) return;
		const patch = this.history.undo();
		if (!patch) return;
		const layer = this.layers.find((item) => item.id === patch.layerId);
		if (!layer) return;
		layer.ctx.putImageData(patch.before, patch.x, patch.y);
		this.scheduleSave();
		this.emit();
	}
	redo() {
		if (this.drawing) return;
		const patch = this.history.redo();
		if (!patch) return;
		const layer = this.layers.find((item) => item.id === patch.layerId);
		if (!layer) return;
		layer.ctx.putImageData(patch.after, patch.x, patch.y);
		this.hasInk = true;
		this.scheduleSave();
		this.emit();
	}
	clearLayer() {
		const layer = this.activeLayer();
		const before = layer.ctx.getImageData(0, 0, this.artW, this.artH);
		layer.ctx.clearRect(0, 0, this.artW, this.artH);
		const after = layer.ctx.getImageData(0, 0, this.artW, this.artH);
		this.history.push(layer.id, {
			x: 0,
			y: 0,
			w: this.artW,
			h: this.artH
		}, before, after);
		this.scheduleSave();
		this.flash("لایه پاک شد");
	}
	clearAll() {
		for (const layer of this.layers) {
			const before = layer.ctx.getImageData(0, 0, this.artW, this.artH);
			layer.ctx.clearRect(0, 0, this.artW, this.artH);
			const after = layer.ctx.getImageData(0, 0, this.artW, this.artH);
			this.history.push(layer.id, {
				x: 0,
				y: 0,
				w: this.artW,
				h: this.artH
			}, before, after);
		}
		this.scheduleSave();
		this.flash("بوم پاک شد");
	}
	addLayer() {
		if (this.layers.length >= MAX_LAYERS) {
			this.flash("حداکثر ۶ لایه");
			return;
		}
		const layer = this.createLayer(`لایه ${this.layers.length + 1}`);
		const index = this.active + 1;
		this.layers.splice(index, 0, layer);
		this.active = index;
		this.orderDom();
		this.syncLayerStyles();
		this.scheduleSave();
		this.emit();
	}
	deleteLayer(id) {
		if (this.layers.length <= 1) {
			this.clearLayer();
			return;
		}
		const index = this.layers.findIndex((layer) => layer.id === id);
		if (index < 0) return;
		this.layers[index].canvas.remove();
		this.layers.splice(index, 1);
		this.active = Math.max(0, Math.min(this.active, this.layers.length - 1));
		this.orderDom();
		this.scheduleSave();
		this.emit();
	}
	moveLayer(id, dir) {
		const index = this.layers.findIndex((layer) => layer.id === id);
		const next = index + dir;
		if (index < 0 || next < 0 || next >= this.layers.length) return;
		const [layer] = this.layers.splice(index, 1);
		this.layers.splice(next, 0, layer);
		if (this.active === index) this.active = next;
		else if (this.active === next) this.active = index;
		this.orderDom();
		this.scheduleSave();
		this.emit();
	}
	setActiveLayer(id) {
		const index = this.layers.findIndex((layer) => layer.id === id);
		if (index < 0) return;
		this.active = index;
		this.sel = null;
		this.orderDom();
		this.drawChrome();
		this.scheduleSave();
		this.emit();
	}
	setLayerVisible(id, visible) {
		const layer = this.layers.find((item) => item.id === id);
		if (!layer) return;
		layer.visible = visible;
		layer.canvas.style.visibility = visible ? "visible" : "hidden";
		this.scheduleSave();
		this.emit();
	}
	setLayerOpacity(id, opacity) {
		const layer = this.layers.find((item) => item.id === id);
		if (!layer) return;
		layer.opacity = clamp(opacity, .05, 1);
		layer.canvas.style.opacity = String(layer.opacity);
		this.scheduleSave();
		this.emit();
	}
	async loadReference(file) {
		try {
			const img = await blobToImage(file);
			const maxEdge = Math.max(this.artW, this.artH) * 2;
			const scale = Math.min(1, maxEdge / Math.max(img.naturalWidth, img.naturalHeight));
			const src = document.createElement("canvas");
			src.width = Math.max(1, Math.round(img.naturalWidth * scale));
			src.height = Math.max(1, Math.round(img.naturalHeight * scale));
			ctx2d(src).drawImage(img, 0, 0, src.width, src.height);
			const blob = await canvasToBlob(src);
			const fit = Math.min(this.artW * .9 / src.width, this.artH * .9 / src.height, 1);
			const w = Math.max(36, src.width * fit);
			const h = Math.max(36, src.height * fit);
			this.refBlob = blob;
			this.ref = {
				source: src,
				baseW: w,
				baseH: h,
				x: (this.artW - w) / 2,
				y: (this.artH - h) / 2,
				w,
				h,
				rotation: 0,
				opacity: .5,
				locked: false
			};
			this.drawRef();
			this.scheduleSave();
			this.flash("عکس اضافه شد. بکشید، بعد قفل کنید");
		} catch {
			this.flash("خواندن عکس ممکن نشد");
		}
	}
	setRefOpacity(opacity) {
		if (!this.ref) return;
		this.ref.opacity = clamp(opacity, .05, 1);
		this.drawRef();
		this.scheduleSave();
		this.emit();
	}
	setRefLocked(locked) {
		if (!this.ref) return;
		this.ref.locked = locked;
		this.drawRef();
		this.scheduleSave();
		this.flash(locked ? "عکس قفل شد" : "عکس باز شد — می‌توانید جابه‌جا کنید");
	}
	setRefRotation(deg) {
		if (!this.ref) return;
		this.ref.rotation = deg * Math.PI / 180;
		this.drawRef();
		this.scheduleSave();
		this.emit();
	}
	setRefScale(scale) {
		if (!this.ref) return;
		const next = clamp(scale, .15, 4);
		const cx = this.ref.x + this.ref.w / 2;
		const cy = this.ref.y + this.ref.h / 2;
		this.ref.w = Math.max(36, this.ref.baseW * next);
		this.ref.h = Math.max(36, this.ref.baseH * next);
		this.ref.x = cx - this.ref.w / 2;
		this.ref.y = cy - this.ref.h / 2;
		this.drawRef();
		this.scheduleSave();
		this.emit();
	}
	clearReference() {
		this.ref = null;
		this.refBlob = null;
		this.drawRef();
		this.scheduleSave();
		this.flash("عکس مرجع حذف شد");
	}
	newDocument(w, h) {
		this.ref = null;
		this.refBlob = null;
		this.hasInk = false;
		this.rebuildWorld(w, h);
		this.addLayerInternal("لایه ۱");
		this.syncLayerStyles();
		this.fit(false);
		this.scheduleSave();
		this.flash("بوم تازه آماده است");
	}
	async exportPng(withReference) {
		const canvas = document.createElement("canvas");
		canvas.width = this.artW;
		canvas.height = this.artH;
		const ctx = ctx2d(canvas);
		ctx.drawImage(this.paper, 0, 0);
		if (withReference) ctx.drawImage(this.refCanvas, 0, 0);
		for (const layer of this.layers) {
			if (!layer.visible) continue;
			ctx.globalAlpha = layer.opacity;
			ctx.drawImage(layer.canvas, 0, 0);
		}
		ctx.globalAlpha = 1;
		const blob = await canvasToBlob(canvas);
		const file = new File([blob], "negar.png", { type: "image/png" });
		const share = navigator.share?.bind(navigator);
		const can = typeof navigator.canShare === "function" && (() => {
			try {
				return navigator.canShare({ files: [file] });
			} catch {
				return false;
			}
		})();
		if (share && can) try {
			await share({
				files: [file],
				title: "نگار"
			});
			return;
		} catch (error) {
			if (error instanceof Error && error.name === "AbortError") return;
		}
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "negar.png";
		link.click();
		window.setTimeout(() => URL.revokeObjectURL(url), 1500);
		this.flash("فایل PNG ذخیره شد");
	}
	rememberColor() {
		const color = this.color.toLowerCase();
		this.recent = [color, ...this.recent.filter((item) => item !== color)].slice(0, 12);
		this.persistPrefs();
	}
	flash(message) {
		this.message = message;
		this.emit();
		window.clearTimeout(this.msgTimer);
		this.msgTimer = window.setTimeout(() => {
			this.message = null;
			if (!this.destroyed) this.emit();
		}, 2400);
	}
	persistPrefs() {
		savePrefs({
			color: this.color,
			recent: this.recent,
			tool: this.tool,
			brushKind: this.brushKind,
			eraserSoft: this.eraserSoft,
			shape: this.shape,
			filled: this.filled,
			symmetric: this.symmetric,
			fillTolerance: this.fillTolerance,
			paper: this.paperColor,
			settings: this.settings
		});
	}
	scheduleSave() {
		window.clearTimeout(this.saveTimer);
		this.saveTimer = window.setTimeout(() => void this.persist(), 800);
	}
	async persist() {
		if (this.destroyed || this.restoring) return;
		try {
			const layers = [];
			for (const layer of this.layers) layers.push({
				id: layer.id,
				name: layer.name,
				visible: layer.visible,
				opacity: layer.opacity,
				png: await canvasToBlob(layer.canvas)
			});
			await saveDoc({
				version: 1,
				artW: this.artW,
				artH: this.artH,
				paper: this.paperColor,
				hasInk: this.hasInk,
				activeId: this.activeLayer().id,
				layers,
				reference: this.ref && this.refBlob ? {
					png: this.refBlob,
					x: this.ref.x,
					y: this.ref.y,
					w: this.ref.w,
					h: this.ref.h,
					baseW: this.ref.baseW,
					baseH: this.ref.baseH,
					rotation: this.ref.rotation,
					opacity: this.ref.opacity,
					locked: this.ref.locked
				} : null
			});
			if (this.destroyed) return;
			this.savedTick++;
			this.emit();
		} catch {}
	}
	async restore() {
		const gen = ++this.restoreGen;
		const doc = await loadDoc();
		if (this.destroyed || gen !== this.restoreGen) return;
		if (!doc || doc.version !== 1 || !doc.layers?.length) {
			this.restoring = false;
			this.fit(false);
			this.emit();
			return;
		}
		try {
			this.rebuildWorld(doc.artW, doc.artH);
			this.paperColor = doc.paper || this.paperColor;
			this.drawPaper();
			this.hasInk = !!doc.hasInk;
			for (const saved of doc.layers) {
				const layer = this.createLayer(saved.name, saved.id);
				layer.visible = saved.visible;
				layer.opacity = saved.opacity;
				const img = await blobToImage(saved.png);
				if (this.destroyed || gen !== this.restoreGen) return;
				layer.ctx.drawImage(img, 0, 0, this.artW, this.artH);
				layer.canvas.style.opacity = String(layer.opacity);
				layer.canvas.style.visibility = layer.visible ? "visible" : "hidden";
				this.layers.push(layer);
			}
			const index = this.layers.findIndex((layer) => layer.id === doc.activeId);
			this.active = index >= 0 ? index : this.layers.length - 1;
			if (doc.reference) {
				const img = await blobToImage(doc.reference.png);
				if (this.destroyed || gen !== this.restoreGen) return;
				const src = document.createElement("canvas");
				src.width = img.naturalWidth;
				src.height = img.naturalHeight;
				ctx2d(src).drawImage(img, 0, 0);
				this.refBlob = doc.reference.png;
				this.ref = {
					source: src,
					x: doc.reference.x,
					y: doc.reference.y,
					w: doc.reference.w,
					h: doc.reference.h,
					baseW: doc.reference.baseW,
					baseH: doc.reference.baseH,
					rotation: doc.reference.rotation,
					opacity: doc.reference.opacity,
					locked: doc.reference.locked
				};
			}
			this.orderDom();
			this.drawRef();
			this.restoring = false;
			this.fit(false);
			if (doc.hasInk || doc.reference) this.flash("نقاشی بازیابی شد");
			else this.emit();
		} catch {
			if (this.layers.length === 0) {
				this.rebuildWorld(1080, 1440);
				this.addLayerInternal("لایه ۱");
				this.drawPaper();
			}
			this.restoring = false;
			this.fit(false);
			this.emit();
		}
	}
	syncCursor() {
		const map = {
			brush: "crosshair",
			pencil: "crosshair",
			eraser: "cell",
			fill: "crosshair",
			eyedropper: "crosshair",
			shape: "crosshair",
			select: "crosshair",
			hand: "grab"
		};
		this.stage.style.cursor = map[this.tool];
	}
};
function pointIn(x, y, rx, ry, rw, rh) {
	return x >= rx && y >= ry && x <= rx + rw && y <= ry + rh;
}
function sliceImage(full, rect) {
	const out = new ImageData(rect.w, rect.h);
	for (let y = 0; y < rect.h; y++) {
		const src = ((rect.y + y) * full.width + rect.x) * 4;
		out.data.set(full.data.subarray(src, src + rect.w * 4), y * rect.w * 4);
	}
	return out;
}
var KIND_ICON = {
	hard: Circle,
	soft: Droplets,
	spray: SprayCan,
	calligraphy: PenLine,
	watercolor: Droplets,
	charcoal: Brush,
	crayon: Pencil,
	pencil: Pencil
};
function PaintStudio() {
	const studioRef = (0, import_react.useRef)(null);
	const stageRef = (0, import_react.useRef)(null);
	const worldRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const zoomRef = (0, import_react.useRef)(null);
	const [snap, setSnap] = (0, import_react.useState)(defaultSnapshot);
	const [panel, setPanel] = (0, import_react.useState)(null);
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	const [full, setFull] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const studio = studioRef.current;
		const stage = stageRef.current;
		const world = worldRef.current;
		if (!studio || !stage || !world) return;
		const engine = new PaintEngine();
		engineRef.current = engine;
		engineHandle = engine;
		const unsub = engine.subscribe(() => setSnap(engine.getSnapshot()));
		engine.onZoom = (scale) => {
			if (zoomRef.current) zoomRef.current.textContent = `${Math.round(scale * 100)}%`;
		};
		engine.attach(studio, stage, world);
		return () => {
			unsub();
			engine.destroy();
			engineHandle = null;
			engineRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (zoomRef.current) zoomRef.current.textContent = `${Math.round(snap.zoom * 100)}%`;
	}, [snap.zoom]);
	(0, import_react.useEffect)(() => {
		const onChange = () => setFull(!!document.fullscreenElement);
		document.addEventListener("fullscreenchange", onChange);
		return () => document.removeEventListener("fullscreenchange", onChange);
	}, []);
	const engine = engineRef.current;
	function toggleTool(tool, sheet) {
		if (snap.tool === tool) setPanel(sheet);
		else engineRef.current?.setTool(tool);
	}
	function ask(next) {
		setConfirm(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "studio",
		ref: studioRef,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stage",
				ref: stageRef,
				role: "img",
				"aria-label": "بوم نقاشی",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "world",
						ref: worldRef
					}),
					!snap.restoring && !snap.hasInk && !snap.reference && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hint",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "برای نقاشی انگشت را بکشید" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "دو انگشت بوم را زوم و جابه‌جا می‌کند. عکس مرجع را از نوار پایین اضافه کنید." })]
					}),
					snap.reference && !snap.reference.locked && panel !== "ref" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ref-banner",
						children: "عکس باز است. یک انگشت جابه‌جا می‌کند، دو انگشت اندازه و چرخش. برای نقاشی روی آن، قفل کنید."
					}),
					snap.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "toast",
						children: snap.message
					}),
					snap.restoring && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "restore-veil",
						children: "در حال باز کردن بوم…"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "topbar",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "wordmark",
						children: "نگار"
					}),
					snap.savedTick > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "saved-pip",
						"aria-label": "ذخیره شد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "zoom-btn",
						onClick: () => engineRef.current?.fit(true),
						"aria-label": "تناسب صفحه",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							ref: zoomRef,
							children: "100%"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "top-actions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "icon-btn",
								"aria-label": "واگرد",
								disabled: !snap.canUndo,
								onClick: () => engineRef.current?.undo(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {
									size: 20,
									strokeWidth: 1.75
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "icon-btn",
								"aria-label": "ازنو",
								disabled: !snap.canRedo,
								onClick: () => engineRef.current?.redo(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Redo2, {
									size: 20,
									strokeWidth: 1.75
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "icon-btn",
								"aria-label": "ذخیره PNG",
								onClick: () => void engineRef.current?.exportPng(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									size: 20,
									strokeWidth: 1.75
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "icon-btn",
								"aria-label": "منو",
								"aria-pressed": panel === "menu",
								onClick: () => setPanel(panel === "menu" ? null : "menu"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
									size: 20,
									strokeWidth: 1.75
								})
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock",
				"aria-label": "ابزارها",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "tool-scroller",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "tool-btn color-btn",
							"aria-label": "رنگ",
							"aria-pressed": panel === "color",
							onClick: () => setPanel(panel === "color" ? null : "color"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "color-swatch",
								style: { background: snap.color }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "قلم‌مو",
							pressed: snap.tool === "brush",
							onClick: () => toggleTool("brush", "brush"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brush, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "پاک‌کن",
							pressed: snap.tool === "eraser",
							onClick: () => toggleTool("eraser", "eraser"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolButton, {
							label: "عکس مرجع",
							pressed: panel === "ref",
							hot: !!snap.reference && !snap.reference.locked,
							onClick: () => setPanel(panel === "ref" ? null : "ref"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
								size: 22,
								strokeWidth: 1.75
							}), snap.reference && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ref-dot" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "تنظیمات ابزار",
							pressed: panel === "brush" || panel === "pencil" || panel === "eraser" || panel === "shape" || panel === "fill",
							onClick: () => openAdjust(snap.tool, setPanel),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "تناسب صفحه",
							onClick: () => engineRef.current?.fit(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Focus, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "dock-sep" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "مداد",
							pressed: snap.tool === "pencil",
							onClick: () => toggleTool("pencil", "pencil"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "سطل رنگ",
							pressed: snap.tool === "fill",
							onClick: () => toggleTool("fill", "fill"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaintBucket, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "قطره‌چکان",
							pressed: snap.tool === "eyedropper",
							onClick: () => engineRef.current?.setTool("eyedropper"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pipette, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "شکل",
							pressed: snap.tool === "shape",
							onClick: () => toggleTool("shape", "shape"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "انتخاب",
							pressed: snap.tool === "select",
							onClick: () => engineRef.current?.setTool("select"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crop, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "دست",
							pressed: snap.tool === "hand",
							onClick: () => engineRef.current?.setTool("hand"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, {
								size: 22,
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							label: "لایه‌ها",
							pressed: panel === "layers",
							onClick: () => setPanel(panel === "layers" ? null : "layers"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {
								size: 22,
								strokeWidth: 1.75
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				open: panel !== null,
				title: panel ? {
					brush: "قلم‌مو",
					pencil: "مداد",
					eraser: "پاک‌کن",
					shape: "شکل",
					fill: "سطل رنگ",
					color: "رنگ",
					ref: "عکس مرجع",
					layers: "لایه‌ها",
					menu: "منو",
					help: "حرکت بوم"
				}[panel] : "",
				onClose: () => setPanel(null),
				children: [
					panel === "color" && engine && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorPanel, {
						color: snap.color,
						recent: snap.recent,
						onChange: (value, commit) => engineRef.current?.setColor(value, commit)
					}),
					panel === "brush" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrushFields, {
						snap,
						kind: snap.brushKind,
						onKind: (kind) => engineRef.current?.setBrushKind(kind),
						eraser: false
					}),
					panel === "pencil" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrushFields, {
						snap,
						kind: "pencil",
						eraser: false
					}),
					panel === "eraser" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "seg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "seg-btn",
							"aria-pressed": !snap.eraserSoft,
							onClick: () => engineRef.current?.setEraserSoft(false),
							children: "سخت"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "seg-btn",
							"aria-pressed": snap.eraserSoft,
							onClick: () => engineRef.current?.setEraserSoft(true),
							children: "نرم"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrushFields, {
						snap,
						kind: snap.eraserSoft ? "soft" : "hard",
						eraser: true
					})] }),
					panel === "shape" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShapeFields, { snap }),
					panel === "fill" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "تلورانس",
						value: snap.fillTolerance,
						min: 0,
						max: 80,
						step: 1,
						format: (n) => String(n),
						onChange: (n) => engineRef.current?.setFillTolerance(n)
					}),
					panel === "ref" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefPanel, {
						snap,
						onUpload: () => fileRef.current?.click(),
						onDelete: () => ask({
							title: "حذف عکس مرجع؟",
							body: "نقاشی شما می‌ماند. فقط عکس زیر آن حذف می‌شود.",
							confirmLabel: "حذف",
							danger: true,
							onYes: () => engineRef.current?.clearReference()
						})
					}),
					panel === "layers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayersPanel, {
						snap,
						onDelete: (id) => ask({
							title: "حذف لایه؟",
							body: "این کار واگرد ندارد.",
							confirmLabel: "حذف لایه",
							danger: true,
							onYes: () => engineRef.current?.deleteLayer(id)
						})
					}),
					panel === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPanel, {
						snap,
						full,
						onConfirm: ask,
						onClose: () => setPanel(null)
					}),
					panel === "help" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "help-copy",
						children: "دو انگشت همیشه بوم را زوم و جابه‌جا می‌کند، از ۵۰٪ تا ۸۰۰٪. ابزار دست با یک انگشت بوم را می‌کشد. چرخ ماوس روی دسکتاپ هم زوم می‌کند. فاصلهٔ صفحه‌کلید دست را موقتاً فعال می‌کند."
					})
				]
			}),
			confirm && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "modal-root",
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "confirm-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "modal-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "confirm-title",
							children: confirm.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: confirm.body }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "modal-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-btn",
								onClick: () => setConfirm(null),
								children: "انصراف"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `text-btn ${confirm.danger ? "danger" : "primary"}`,
								onClick: () => {
									confirm.onYes();
									setConfirm(null);
								},
								children: confirm.confirmLabel
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: "image/*",
				hidden: true,
				onChange: (event) => {
					const file = event.target.files?.[0];
					event.target.value = "";
					if (file) engineRef.current?.loadReference(file);
				}
			})
		]
	});
}
function openAdjust(tool, setPanel) {
	if (tool === "pencil") setPanel("pencil");
	else if (tool === "eraser") setPanel("eraser");
	else if (tool === "shape") setPanel("shape");
	else if (tool === "fill") setPanel("fill");
	else if (tool === "hand" || tool === "select" || tool === "eyedropper") setPanel("help");
	else setPanel("brush");
}
function ToolButton({ label, pressed, hot, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: `tool-btn${hot ? " is-hot" : ""}`,
		"aria-label": label,
		"aria-pressed": pressed,
		onClick,
		children
	});
}
function Sheet({ open, title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `sheet-root${open ? " open" : ""}`,
		"aria-hidden": !open,
		inert: !open ? true : void 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "sheet-backdrop",
			"aria-label": "بستن",
			tabIndex: open ? 0 : -1,
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sheet-handle" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sheet-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "icon-btn",
						"aria-label": "بستن",
						onClick: onClose,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
							size: 18,
							strokeWidth: 1.75
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sheet-body",
					children
				})
			]
		})]
	});
}
function Field({ label, value, min, max, step, format, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "field-label",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "field-value",
				children: format(value)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "slider",
			type: "range",
			min,
			max,
			step,
			value,
			"aria-label": label,
			onChange: (event) => onChange(Number(event.target.value))
		})]
	});
}
function StrokePreview({ kind, color, size, hardness, opacity, eraser }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		renderBrushPreview(canvas, kind, color, size, hardness, opacity, eraser);
	}, [
		kind,
		color,
		size,
		hardness,
		opacity,
		eraser
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		className: "stroke-preview",
		"aria-hidden": "true"
	});
}
function BrushFields({ snap, kind, eraser, onKind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StrokePreview, {
			kind,
			color: snap.color,
			size: snap.size,
			hardness: snap.hardness,
			opacity: snap.opacity,
			eraser
		}),
		onKind && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "kind-grid",
			children: BRUSH_KINDS.map((item) => {
				const Icon = KIND_ICON[item.id];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "kind-btn",
					"aria-pressed": snap.brushKind === item.id,
					onClick: () => onKind(item.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						size: 18,
						strokeWidth: 1.75
					}), item.label]
				}, item.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "اندازه",
			value: snap.size,
			min: 1,
			max: 128,
			step: 1,
			format: (n) => `${n}`,
			onChange: (n) => live().setSize(n)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "شفافیت",
			value: snap.opacity,
			min: .05,
			max: 1,
			step: .01,
			format: (n) => `${Math.round(n * 100)}%`,
			onChange: (n) => live().setOpacity(n)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "سختی",
			value: snap.hardness,
			min: 0,
			max: 1,
			step: .01,
			format: (n) => `${Math.round(n * 100)}%`,
			onChange: (n) => live().setHardness(n)
		})
	] });
}
function ShapeFields({ snap }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "choice-row",
			children: [
				{
					id: "line",
					label: "خط",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 18 })
				},
				{
					id: "rect",
					label: "مستطیل",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { size: 18 })
				},
				{
					id: "ellipse",
					label: "دایره",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { size: 18 })
				}
			].map((shape) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "choice-btn",
				"aria-pressed": snap.shape === shape.id,
				onClick: () => live().setShape(shape.id),
				children: [shape.icon, shape.label]
			}, shape.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "seg seg-gap",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "seg-btn",
				"aria-pressed": !snap.filled,
				onClick: () => live().setFilled(false),
				children: "توخالی"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "seg-btn",
				"aria-pressed": snap.filled,
				onClick: () => live().setFilled(true),
				children: "توپر"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "seg seg-gap",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "seg-btn",
				"aria-pressed": !snap.symmetric,
				onClick: () => live().setSymmetric(false),
				children: "آزاد"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "seg-btn",
				"aria-pressed": snap.symmetric,
				onClick: () => live().setSymmetric(true),
				children: "متقارن"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "ضخامت خط",
			value: snap.size,
			min: 1,
			max: 80,
			step: 1,
			format: (n) => `${n}`,
			onChange: (n) => live().setSize(n)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "شفافیت",
			value: snap.opacity,
			min: .05,
			max: 1,
			step: .01,
			format: (n) => `${Math.round(n * 100)}%`,
			onChange: (n) => live().setOpacity(n)
		})
	] });
}
var engineHandle = null;
function live() {
	if (!engineHandle) throw new Error("engine");
	return engineHandle;
}
function ColorPanel({ color, recent, onChange }) {
	const rgb = hexToRgb(color);
	const hsv = rgbToHsv(rgb.r, rgb.g, rgb.b);
	const apply = (h, s, v, commit) => {
		const next = hsvToRgb(h, s, v);
		onChange(rgbToHex(next.r, next.g, next.b), commit);
	};
	const pickPlane = (event, commit) => {
		const rect = event.currentTarget.getBoundingClientRect();
		const s = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
		const v = Math.min(1, Math.max(0, 1 - (event.clientY - rect.top) / rect.height));
		apply(hsv.h, s, v, commit);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sv-plane",
			style: { background: `hsl(${hsv.h} 100% 50%)` },
			onPointerDown: (event) => {
				event.currentTarget.setPointerCapture(event.pointerId);
				pickPlane(event, false);
			},
			onPointerMove: (event) => {
				if (event.currentTarget.hasPointerCapture(event.pointerId)) pickPlane(event, false);
			},
			onPointerUp: (event) => pickPlane(event, true),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sv-white" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sv-black" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sv-cursor",
					style: {
						left: `${hsv.s * 100}%`,
						top: `${(1 - hsv.v) * 100}%`
					}
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "طیف",
			value: hsv.h,
			min: 0,
			max: 360,
			step: 1,
			format: (n) => `${Math.round(n)}°`,
			onChange: (n) => apply(n, hsv.s || 1, hsv.v || 1, false)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "section-label",
			children: "رنگ‌دانه‌ها"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "swatch-row",
			children: PIGMENTS.map((pigment) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "pigment",
				style: { background: pigment },
				"aria-label": pigment,
				"aria-pressed": color.toLowerCase() === pigment,
				onClick: () => onChange(pigment, true)
			}, pigment))
		}),
		recent.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "section-label",
			children: "اخیر"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "swatch-row",
			children: recent.map((pigment) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "pigment",
				style: { background: pigment },
				"aria-label": pigment,
				"aria-pressed": color.toLowerCase() === pigment,
				onClick: () => onChange(pigment, true)
			}, pigment))
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hex-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: color.toUpperCase() }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "native-color",
				type: "color",
				"aria-label": "رنگ سیستم",
				value: safeColorInput(color),
				onChange: (event) => onChange(event.target.value, true)
			})]
		})
	] });
}
function safeColorInput(color) {
	return /^#[0-9a-fA-F]{6}$/.test(color) ? color : "#1c1917";
}
function RefPanel({ snap, onUpload, onDelete }) {
	const ref = snap.reference;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack-gap",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "text-btn primary",
			onClick: onUpload,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { size: 18 }), "انتخاب از گالری"]
		}), ref ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "help-copy",
				children: "عکس همیشه زیر نقاشی است. قبل از قفل، آن را بکشید. دو انگشت روی خود عکس اندازه و چرخش می‌دهد."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "شفافیت عکس",
				value: ref.opacity,
				min: .05,
				max: 1,
				step: .01,
				format: (n) => `${Math.round(n * 100)}%`,
				onChange: (n) => live().setRefOpacity(n)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "چرخش",
				value: Math.round(ref.rotation * 180 / Math.PI),
				min: -180,
				max: 180,
				step: 1,
				format: (n) => `${n}°`,
				onChange: (n) => live().setRefRotation(n)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "اندازه",
				value: ref.scale,
				min: .2,
				max: 3,
				step: .01,
				format: (n) => `${Math.round(n * 100)}%`,
				onChange: (n) => live().setRefScale(n)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "text-btn",
				onClick: () => live().setRefLocked(!ref.locked),
				children: [ref.locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { size: 18 }), ref.locked ? "باز کردن قفل" : "قفل کردن عکس"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "text-btn danger",
				onClick: onDelete,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 18 }), "حذف عکس"]
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "help-copy",
			children: "عکسی را زیر نقاشی بگذارید، شفافیتش را کم کنید و بعد از تنظیم، قفلش کنید تا موقع کشیدن جابه‌جا نشود."
		})]
	});
}
function LayersPanel({ snap, onDelete }) {
	const ordered = [...snap.layers].reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stack-gap",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-btn primary",
				onClick: () => live().addLayer(),
				children: "لایهٔ جدید"
			}),
			ordered.map((layer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `layer-row${layer.active ? " is-active" : ""}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "icon-btn",
						"aria-label": layer.visible ? "پنهان کردن" : "نمایش",
						onClick: () => live().setLayerVisible(layer.id, !layer.visible),
						children: layer.visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "layer-name",
						onClick: () => live().setActiveLayer(layer.id),
						children: layer.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "icon-btn",
						"aria-label": "بردن بالاتر",
						onClick: () => live().moveLayer(layer.id, 1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "icon-btn",
						"aria-label": "بردن پایین‌تر",
						onClick: () => live().moveLayer(layer.id, -1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { size: 18 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "icon-btn",
						"aria-label": "حذف لایه",
						onClick: () => onDelete(layer.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 16 })
					})
				]
			}, layer.id)),
			snap.layers.find((layer) => layer.active) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "شفافیت لایه",
				value: snap.layers.find((layer) => layer.active)?.opacity ?? 1,
				min: .05,
				max: 1,
				step: .01,
				format: (n) => `${Math.round(n * 100)}%`,
				onChange: (n) => {
					const active = snap.layers.find((layer) => layer.active);
					if (active) live().setLayerOpacity(active.id, n);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "section-label",
				children: "رنگ کاغذ"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "preset-row",
				children: [PAPERS.map((paper) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "paper-dot",
					style: { background: paper },
					"aria-label": paper,
					"aria-pressed": snap.paper.toLowerCase() === paper,
					onClick: () => live().setPaper(paper)
				}, paper)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "native-color",
					type: "color",
					"aria-label": "رنگ کاغذ دلخواه",
					value: safeColorInput(snap.paper),
					onChange: (event) => live().setPaper(event.target.value)
				})]
			})
		]
	});
}
function MenuPanel({ snap, full, onConfirm, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "menu-block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "text-btn primary",
				onClick: () => void live().exportPng(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 18 }), "ذخیره PNG با عکس"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-btn",
				onClick: () => void live().exportPng(false),
				children: "ذخیره فقط نقاشی"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "choice-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "choice-btn",
						onClick: () => live().zoomBy(1.25),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { size: 18 }), "زوم"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "choice-btn",
						onClick: () => live().zoomBy(1 / 1.25),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { size: 18 }), "کوچک"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "choice-btn",
						onClick: () => live().fit(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Focus, { size: 18 }), "تناسب"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-btn",
				onClick: () => {
					(!document.fullscreenElement ? document.documentElement.requestFullscreen?.() : document.exitFullscreen?.())?.catch(() => void 0);
				},
				children: full ? "خروج از تمام‌صفحه" : "تمام‌صفحه"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "section-label",
				children: "بوم تازه"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "choice-row",
				children: ART_PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "choice-btn",
					onClick: () => {
						const run = () => {
							live().newDocument(preset.w, preset.h);
							onClose();
						};
						if (snap.hasInk || snap.reference) onConfirm({
							title: "بوم تازه؟",
							body: `اندازه ${preset.label} نقاشی فعلی را جایگزین می‌کند. واگرد آن را برنمی‌گرداند.`,
							confirmLabel: preset.label,
							danger: true,
							onYes: run
						});
						else run();
					},
					children: preset.label
				}, preset.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-btn danger",
				onClick: () => onConfirm({
					title: "پاک کردن این لایه؟",
					body: "با واگرد می‌توانید برگردانید.",
					confirmLabel: "پاک شود",
					danger: true,
					onYes: () => live().clearLayer()
				}),
				children: "پاک کردن لایه"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "text-btn danger",
				onClick: () => onConfirm({
					title: "پاک کردن همهٔ لایه‌ها؟",
					body: "کاغذ و عکس مرجع می‌مانند.",
					confirmLabel: "پاک شود",
					danger: true,
					onYes: () => live().clearAll()
				}),
				children: "پاک کردن نقاشی"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "help-copy",
				children: "نقاشی روی همین گوشی موقتاً ذخیره می‌شود تا اگر برنامه بسته شد، برگردد."
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaintStudio, {});
}
//#endregion
export { Home as component };
